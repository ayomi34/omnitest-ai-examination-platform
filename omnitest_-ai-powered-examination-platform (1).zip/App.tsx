import React, { useState, useCallback } from 'react';
import { User, Exam, Role, Submission, Question, QuestionType } from './types';
import Login from './components/Login';
import Signup from './components/Signup';
import StudentDashboard from './components/StudentDashboard';
import TeacherDashboard from './components/teacher/TeacherDashboard';
import AdminDashboard from './components/admin/AdminDashboard';
import ExamView from './components/ExamView';
import ExamForm from './components/teacher/ExamForm';
import GradingView from './components/teacher/GradingView';
import Chatbot from './components/chatbot/Chatbot';
import { v4 as uuidv4 } from 'uuid';
import { MOCK_USERS, MOCK_EXAMS, MOCK_SUBMISSIONS } from './services/mockData';

// Helper to shuffle array for question randomization
const shuffleArray = (array: any[]) => {
  const newArray = [...array];
  for (let i = newArray.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [newArray[i], newArray[j]] = [newArray[j], newArray[i]];
  }
  return newArray;
};

// Helper functions for user generation
const generateUniqueUsername = (fullName: string, allUsers: User[]): string => {
    // Generate a base username from the full name (e.g., "John Doe" -> "jdoe")
    const nameParts = fullName.trim().toLowerCase().split(' ').filter(Boolean);
    if (nameParts.length === 0) return `student${Date.now()}`;
    
    const baseUsername = nameParts.length > 1 
      ? `${nameParts[0].charAt(0)}${nameParts[nameParts.length - 1]}`
      : nameParts[0];

    if (!baseUsername) return `student${Date.now()}`;

    let finalUsername = baseUsername.replace(/[^a-z0-9]/g, '');
    let counter = 1;
    const existingUsernames = new Set(allUsers.map(u => u.username));

    while (existingUsernames.has(finalUsername)) {
        finalUsername = `${baseUsername}${counter}`;
        counter++;
    }
    return finalUsername;
};

const generateRandomPassword = (length: number = 8): string => {
    const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    let password = "";
    for (let i = 0; i < length; i++) {
        password += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return password;
};


type AppView = 'login' | 'signup' | 'dashboard';

const App: React.FC = () => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [currentView, setCurrentView] = useState<AppView>('login');
  
  // State to manage the entire application's data, simulating a database
  const [users, setUsers] = useState<User[]>(MOCK_USERS);
  const [exams, setExams] = useState<Exam[]>(MOCK_EXAMS);
  const [submissions, setSubmissions] = useState<Submission[]>(MOCK_SUBMISSIONS);

  // State to manage the current view/activity
  const [activeExam, setActiveExam] = useState<Exam | null>(null);
  const [editingExam, setEditingExam] = useState<Exam | null | 'new'>(null);
  const [gradingExam, setGradingExam] = useState<Exam | null>(null);
  const [examResults, setExamResults] = useState<Submission | null>(null);

  const handleLogin = useCallback((username: string, password: string): User | null => {
    const user = users.find(u => u.username.toLowerCase() === username.toLowerCase() && u.password === password);
    if (user) {
      setCurrentUser(user);
      setCurrentView('dashboard');
      return user;
    }
    return null;
  }, [users]);
  
  const handleSignup = useCallback((newUser: Omit<User, 'id' | 'role'>) => {
    const userExists = users.some(u => u.username.toLowerCase() === newUser.username.toLowerCase());
    if (userExists) {
        return { success: false, message: 'Username is already taken.' };
    }
    const user: User = { ...newUser, id: uuidv4(), role: Role.Student };
    setUsers(prev => [...prev, user]);
    setCurrentUser(user);
    setCurrentView('dashboard');
    return { success: true, message: 'Signup successful!' };
  }, [users]);


  const handleLogout = useCallback(() => {
    setCurrentUser(null);
    setActiveExam(null);
    setExamResults(null);
    setEditingExam(null);
    setGradingExam(null);
    setCurrentView('login');
  }, []);
  
  const handleStartExam = useCallback((exam: Exam) => {
    const randomizedExam = { ...exam, questions: shuffleArray(exam.questions) };
    setActiveExam(randomizedExam);
    setExamResults(null);
  }, []);
  
  const handleSubmitExam = (answers: Record<string, any>) => {
    if (!activeExam || !currentUser) return;

    let score = 0;
    const gradedAnswers: Record<string, { score: number, feedback: string }> = {};
    activeExam.questions.forEach(q => {
      if (q.type === 'mcq') {
          if(answers[q.id] === q.correctAnswer) {
              score += q.points || 1;
              gradedAnswers[q.id] = { score: q.points || 1, feedback: 'Correct' };
          } else {
              gradedAnswers[q.id] = { score: 0, feedback: 'Incorrect' };
          }
      }
      if (q.type === 'fill-in-the-blank') {
          const correct = q.correctAnswer as string[];
          const studentAns = answers[q.id] as string[] || [];
          let allCorrect = true;
          for(let i = 0; i < correct.length; i++) {
              if (studentAns[i]?.trim().toLowerCase() !== correct[i].trim().toLowerCase()) {
                  allCorrect = false;
                  break;
              }
          }
          if(allCorrect) {
              score += q.points || 1;
              gradedAnswers[q.id] = { score: q.points || 1, feedback: 'Correct' };
          } else {
              gradedAnswers[q.id] = { score: 0, feedback: 'Incorrect' };
          }
      }
    });

    const newSubmission: Submission = {
      id: uuidv4(),
      examId: activeExam.id,
      studentId: currentUser.id,
      studentName: currentUser.fullName,
      answers,
      submittedAt: new Date(),
      grades: gradedAnswers,
      finalScore: score
    };

    setSubmissions(prev => [...prev, newSubmission]);
    setExamResults(newSubmission);
    setActiveExam(null);
  };

  const handleSaveExam = (examToSave: Exam) => {
    if (examToSave.id) {
        setExams(prevExams => prevExams.map(e => e.id === examToSave.id ? examToSave : e));
    } else {
        setExams(prevExams => [...prevExams, { ...examToSave, id: uuidv4(), teacherId: currentUser?.id }]);
    }
    setEditingExam(null);
  };
  
  const handleDeleteExam = (examId: string) => {
    if(window.confirm('Are you sure you want to delete this exam and all its submissions?')) {
        setExams(prevExams => prevExams.filter(e => e.id !== examId));
        setSubmissions(prevSubmissions => prevSubmissions.filter(s => s.examId !== examId));
    }
  };

  const handleSaveGrade = (submissionId: string, newGrades: Record<string, { score: number; feedback?: string }>, finalScore: number) => {
    setSubmissions(prevSubmissions => prevSubmissions.map(s => 
      s.id === submissionId 
        ? { ...s, grades: newGrades, finalScore } 
        : s
    ));
  };
  
  // User Management Handlers (for Admin)
  const handleAddUser = (user: Omit<User, 'id'>) => {
    setUsers(prev => [...prev, { ...user, id: uuidv4() }]);
  };

  const handleAddUsersBatch = (usersData: { fullName: string }[]): (User & { plainPassword?: string })[] => {
    const newlyCreatedUsers: (User & { plainPassword?: string })[] = [];
    const currentAndNewUsers = [...users];

    usersData.forEach(userData => {
        if (!userData.fullName || !userData.fullName.trim()) return;

        const username = generateUniqueUsername(userData.fullName, currentAndNewUsers);
        const password = generateRandomPassword();
        
        const newUser: User = {
            id: uuidv4(),
            fullName: userData.fullName.trim(),
            username,
            password,
            email: `${username}@test.com`,
            role: Role.Student,
        };

        newlyCreatedUsers.push({ ...newUser, plainPassword: password });
        currentAndNewUsers.push(newUser);
    });
    
    setUsers(prevUsers => [...prevUsers, ...newlyCreatedUsers.map(({ plainPassword, ...user }) => user)]);
    return newlyCreatedUsers;
  };

  const handleUpdateUser = (updatedUser: User) => {
    // If password is not provided or is empty, keep the old one
    const oldUser = users.find(u => u.id === updatedUser.id);
    if (!updatedUser.password && oldUser) {
        updatedUser.password = oldUser.password;
    }

    setUsers(prevUsers => prevUsers.map(u => u.id === updatedUser.id ? updatedUser : u));

    // Also update the currentUser if they are editing their own profile
    if (currentUser?.id === updatedUser.id) {
        setCurrentUser(updatedUser);
    }
  };

  const handleDeleteUser = (userId: string) => {
    setUsers(prevUsers => prevUsers.filter(u => u.id !== userId));
  };


  const handleReturnToDashboard = () => {
    setExamResults(null);
    setActiveExam(null);
    setEditingExam(null);
    setGradingExam(null);
  };

  if (currentView === 'login') {
    return <Login onLogin={handleLogin} onNavigateToSignup={() => setCurrentView('signup')} />;
  }
  
  if (currentView === 'signup') {
    return <Signup onSignup={handleSignup} onNavigateToLogin={() => setCurrentView('login')} />;
  }

  if (!currentUser) {
    // This case should ideally not be reached if view logic is correct, but as a fallback
    return <Login onLogin={handleLogin} onNavigateToSignup={() => setCurrentView('signup')} />;
  }
  
  const renderDashboard = () => {
    switch(currentUser.role) {
      case Role.Student:
        if (activeExam) {
          return <ExamView exam={activeExam} student={currentUser} onFinish={handleSubmitExam} />;
        }
        return (
          <StudentDashboard 
            student={currentUser} 
            exams={exams} 
            onStartExam={handleStartExam} 
            onLogout={handleLogout}
            results={examResults}
            onReturnToDashboard={handleReturnToDashboard}
          />
        );
      case Role.Teacher:
        if (editingExam) {
          const exam = editingExam === 'new' ? null : editingExam;
          return <ExamForm existingExam={exam} onSave={handleSaveExam} onCancel={() => setEditingExam(null)} />;
        }
        if (gradingExam) {
            return <GradingView 
                exam={gradingExam} 
                submissions={submissions.filter(s => s.examId === gradingExam.id)}
                onBack={() => setGradingExam(null)}
                onSaveGrade={handleSaveGrade}
            />;
        }
        return (
          <TeacherDashboard
            teacher={currentUser}
            exams={exams.filter(e => e.teacherId === currentUser.id)}
            submissions={submissions}
            onLogout={handleLogout}
            onAddNewExam={() => setEditingExam('new')}
            onEditExam={setEditingExam}
            onGradeExam={setGradingExam}
            onDeleteExam={handleDeleteExam}
            onUpdateUser={handleUpdateUser}
            onAddUsersBatch={handleAddUsersBatch}
          />
        );
      case Role.Admin:
        return (
          <AdminDashboard
            admin={currentUser}
            users={users}
            exams={exams}
            submissions={submissions}
            onLogout={handleLogout}
            onAddUser={handleAddUser}
            onUpdateUser={handleUpdateUser}
            onDeleteUser={handleDeleteUser}
            onAddUsersBatch={handleAddUsersBatch}
          />
        );
      default:
        return <div>Role not recognized.</div>;
    }
  }

  return (
    <>
      {renderDashboard()}
      <Chatbot />
    </>
  );
};

export default App;