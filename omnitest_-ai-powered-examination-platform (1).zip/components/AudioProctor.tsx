import React, { useEffect, useRef } from 'react';

interface AudioProctorProps {
  onInfraction: () => void;
}

const LOUD_NOISE_THRESHOLD = 0.2; // Sensitivity for noise detection (0 to 1)
const SUSTAINED_NOISE_DURATION = 1500; // Time in ms noise must be sustained

const AudioProctor: React.FC<AudioProctorProps> = ({ onInfraction }) => {
  const onInfractionRef = useRef(onInfraction);
  onInfractionRef.current = onInfraction;
  const sustainedNoiseTimer = useRef<number | null>(null);

  useEffect(() => {
    let audioContext: AudioContext | null = null;
    let analyser: AnalyserNode | null = null;
    let source: MediaStreamAudioSourceNode | null = null;
    let stream: MediaStream | null = null;
    let animationFrameId: number;

    const monitorAudio = () => {
      if (analyser) {
        const dataArray = new Uint8Array(analyser.frequencyBinCount);
        analyser.getByteFrequencyData(dataArray);
        let sum = 0;
        for (const amplitude of dataArray) {
          sum += amplitude * amplitude;
        }
        const volume = Math.sqrt(sum / dataArray.length) / 128.0; // Normalize

        if (volume > LOUD_NOISE_THRESHOLD) {
            if (!sustainedNoiseTimer.current) {
                sustainedNoiseTimer.current = window.setTimeout(() => {
                    onInfractionRef.current();
                    sustainedNoiseTimer.current = null;
                }, SUSTAINED_NOISE_DURATION);
            }
        } else {
             if (sustainedNoiseTimer.current) {
                clearTimeout(sustainedNoiseTimer.current);
                sustainedNoiseTimer.current = null;
            }
        }
      }
      animationFrameId = requestAnimationFrame(monitorAudio);
    };

    const startMonitoring = async () => {
      try {
        stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
        analyser = audioContext.createAnalyser();
        analyser.fftSize = 256;
        source = audioContext.createMediaStreamSource(stream);
        source.connect(analyser);
        monitorAudio();
      } catch (err) {
        console.error("Audio proctoring disabled:", err);
      }
    };

    startMonitoring();

    return () => {
      cancelAnimationFrame(animationFrameId);
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
      if (audioContext) {
        audioContext.close();
      }
       if (sustainedNoiseTimer.current) {
          clearTimeout(sustainedNoiseTimer.current);
      }
    };
  }, []);

  return null; // This component does not render anything
};

export default AudioProctor;
