import React from 'react';

interface TabSwitchWarningModalProps {
  isOpen: boolean;
  onClose: () => void;
  warnings: number;
  message: string;
}

const TabSwitchWarningModal: React.FC<TabSwitchWarningModalProps> = ({
  isOpen,
  onClose,
  warnings,
  message,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50">
      <div className="bg-white dark:bg-slate-800 rounded-lg shadow-xl p-8 max-w-md w-full transform transition-all animate-fade-in-up">
        <div className="text-center">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 mx-auto text-amber-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
            </svg>
            <h2 className="mt-4 text-2xl font-bold text-slate-900 dark:text-white">Warning Issued</h2>
        </div>
        <div className="mt-4 space-y-4 text-slate-700 dark:text-slate-300 text-center">
            <p>{message || 'You have left the exam environment. Please remain on this page for the duration of the test.'}</p>
            <p className="text-lg font-bold bg-amber-100 dark:bg-amber-900 text-amber-800 dark:text-amber-200 p-3 rounded-lg">
                This is warning <span className="text-2xl">{warnings}</span> of 3.
            </p>
            <p className="font-semibold text-red-600 dark:text-red-400">
                If you receive 3 warnings, your exam will be submitted automatically.
            </p>
        </div>
        <div className="flex justify-center mt-8">
            <button
                onClick={onClose}
                className="px-8 py-3 bg-indigo-600 text-white font-semibold rounded-lg hover:bg-indigo-700 transition"
            >
                Return to Exam
            </button>
        </div>
      </div>
    </div>
  );
};

export default TabSwitchWarningModal;