import React from 'react';
import { User, Exam, Submission } from '../types';

interface StudentDashboardProps {
  student: User;
  exams: Exam[];
  onStartExam: (exam: Exam) => void;
  onLogout: () => void;
  results: Submission | null;
  onReturnToDashboard: () => void;
}

const ResultsView: React.FC<{ results: Submission; exam: Exam | undefined; onReturn: () => void; }> = ({ results, exam, onReturn }) => {
    const totalPoints = exam?.questions.reduce((sum, q) => sum + (q.points || 0), 0) || 0;
    
    return (
        <div className="bg-white dark:bg-slate-800 p-8 rounded-xl shadow-lg animate-fade-in">
            <h2 className="text-2xl font-bold mb-4 text-slate-900 dark:text-white">Results for {exam?.title}</h2>
            <p className="text-lg mb-6 text-slate-600 dark:text-slate-300">
                Your exam has been submitted successfully.
            </p>
            {results.finalScore !== undefined && totalPoints > 0 && (
                 <p className="text-lg mb-6 text-slate-600 dark:text-slate-300">
                    Your preliminary score is <span className="font-bold text-indigo-600 dark:text-indigo-400">{results.finalScore}</span> out of {totalPoints}.
                </p>
            )}
            <p className="text-md mb-6 text-slate-500 dark:text-slate-400">
                Your final grade may be adjusted after your instructor reviews your essay questions.
            </p>
            <button
                onClick={onReturn}
                className="w-full px-6 py-3 bg-indigo-600 text-white font-semibold rounded-lg hover:bg-indigo-700 transition-colors"
            >
                Back to Dashboard
            </button>
        </div>
    );
}


const StudentDashboard: React.FC<StudentDashboardProps> = ({ student, exams, onStartExam, onLogout, results, onReturnToDashboard }) => {
  return (
    <div className="container mx-auto p-4 sm:p-6 lg:p-8">
      <header className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-4xl font-extrabold text-slate-900 dark:text-white">Welcome, {student.fullName}!</h1>
          <p className="text-slate-600 dark:text-slate-400 mt-1">Your student dashboard is ready.</p>
        </div>
        <button
          onClick={onLogout}
          className="px-4 py-2 bg-red-600 text-white font-semibold rounded-lg hover:bg-red-700 transition-colors shadow-md"
        >
          Logout
        </button>
      </header>
      
      <main>
        {results ? (
          <ResultsView results={results} exam={exams.find(e => e.id === results.examId)} onReturn={onReturnToDashboard} />
        ) : (
          <div>
            <h2 className="text-2xl font-bold mb-6 text-slate-800 dark:text-slate-200">Upcoming Exams</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {exams.map(exam => (
                <div key={exam.id} className="bg-white dark:bg-slate-800 rounded-xl shadow-lg overflow-hidden transform hover:-translate-y-1 transition-transform duration-300">
                  <div className="p-6">
                    <div className="flex justify-between items-start">
                        <h3 className="text-xl font-bold text-slate-900 dark:text-white">{exam.title}</h3>
                        <span className="bg-indigo-100 dark:bg-indigo-900 text-indigo-800 dark:text-indigo-300 text-xs font-medium px-2.5 py-1 rounded-full">{exam.subject}</span>
                    </div>
                    <p className="text-slate-600 dark:text-slate-400 mt-2">{exam.questions.length} Questions</p>
                    <p className="text-slate-600 dark:text-slate-400">{exam.duration} Minutes</p>
                    <button
                      onClick={() => onStartExam(exam)}
                      className="mt-6 w-full py-2 px-4 bg-indigo-600 text-white font-semibold rounded-lg hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-colors"
                    >
                      Start Exam
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </main>
    </div>
  );
};

export default StudentDashboard;
