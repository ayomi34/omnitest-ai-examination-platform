import React, { useState } from 'react';
import { User } from '../types';

interface SignupProps {
    onSignup: (user: Omit<User, 'id' | 'role'>) => { success: boolean, message: string };
    onNavigateToLogin: () => void;
}

const Signup: React.FC<SignupProps> = ({ onSignup, onNavigateToLogin }) => {
    const [formData, setFormData] = useState({
        fullName: '',
        username: '',
        email: '',
        password: '',
        confirmPassword: ''
    });
    const [error, setError] = useState('');
    const [isLoading, setIsLoading] = useState(false);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (formData.password !== formData.confirmPassword) {
            setError("Passwords do not match.");
            return;
        }
        setIsLoading(true);
        setError('');

        setTimeout(() => {
            const { confirmPassword, ...newUser } = formData;
            const result = onSignup(newUser);
            if (!result.success) {
                setError(result.message);
            }
            setIsLoading(false);
        }, 1000);
    };

    return (
        <div className="flex items-center justify-center min-h-screen bg-slate-100 dark:bg-slate-900">
            <div className="w-full max-w-md p-8 space-y-8 bg-white dark:bg-slate-800 rounded-2xl shadow-xl">
                <div className="text-center">
                    <h1 className="text-3xl font-bold text-slate-900 dark:text-white">Create an Account</h1>
                    <p className="mt-2 text-sm text-slate-600 dark:text-slate-400">
                        Sign up to start taking exams.
                    </p>
                </div>
                <form className="mt-8 space-y-6" onSubmit={handleSubmit}>
                    <div className="space-y-4">
                        <input name="fullName" type="text" required value={formData.fullName} onChange={handleChange} placeholder="Full Name" className="w-full px-4 py-3 text-lg border-slate-300 dark:border-slate-600 bg-slate-50 dark:bg-slate-700 rounded-lg focus:ring-2 focus:ring-indigo-500 transition" />
                        <input name="username" type="text" required value={formData.username} onChange={handleChange} placeholder="Username" className="w-full px-4 py-3 text-lg border-slate-300 dark:border-slate-600 bg-slate-50 dark:bg-slate-700 rounded-lg focus:ring-2 focus:ring-indigo-500 transition" />
                        <input name="email" type="email" required value={formData.email} onChange={handleChange} placeholder="Email Address" className="w-full px-4 py-3 text-lg border-slate-300 dark:border-slate-600 bg-slate-50 dark:bg-slate-700 rounded-lg focus:ring-2 focus:ring-indigo-500 transition" />
                        <input name="password" type="password" required value={formData.password} onChange={handleChange} placeholder="Password" className="w-full px-4 py-3 text-lg border-slate-300 dark:border-slate-600 bg-slate-50 dark:bg-slate-700 rounded-lg focus:ring-2 focus:ring-indigo-500 transition" />
                        <input name="confirmPassword" type="password" required value={formData.confirmPassword} onChange={handleChange} placeholder="Confirm Password" className="w-full px-4 py-3 text-lg border-slate-300 dark:border-slate-600 bg-slate-50 dark:bg-slate-700 rounded-lg focus:ring-2 focus:ring-indigo-500 transition" />
                    </div>

                    {error && <p className="text-sm text-red-500 text-center">{error}</p>}

                    <div className="text-center text-sm">
                        <button type="button" onClick={onNavigateToLogin} className="font-medium text-indigo-600 hover:text-indigo-500">
                            Already have an account? Sign In
                        </button>
                    </div>

                    <div>
                        <button
                            type="submit"
                            disabled={isLoading}
                            className="w-full flex justify-center py-3 px-4 border border-transparent text-lg font-medium rounded-lg text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition disabled:bg-indigo-400"
                        >
                            {isLoading ? 'Creating Account...' : 'Sign Up'}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default Signup;
