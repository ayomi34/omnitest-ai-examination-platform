import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Exam, Question, User, QuestionType } from '../types';
import Timer from './Timer';
import ProgressBar from './ProgressBar';
import MCQ from './questions/MCQ';
import Essay from './questions/Essay';
import FillInTheBlank from './questions/FillInTheBlank';
import ExamPolicyModal from './ExamPolicyModal';
import ConfirmSubmitModal from './ConfirmSubmitModal';
import TabSwitchWarningModal from './TabSwitchWarningModal';
import AudioProctor from './AudioProctor';

interface ExamViewProps {
  exam: Exam;
  student: User;
  onFinish: (answers: Record<string, any>) => void;
}

const QuestionCard: React.FC<{ question: Question, answer: any, onAnswer: (answer: any) => void }> = ({ question, answer, onAnswer }) => {
    switch (question.type) {
        case QuestionType.MCQ:
            return <MCQ question={question} answer={answer} onAnswer={onAnswer} />;
        case QuestionType.Essay:
            return <Essay question={question} answer={answer} onAnswer={onAnswer} />;
        case QuestionType.FillInTheBlank:
            return <FillInTheBlank question={question} answer={answer} onAnswer={onAnswer} />;
        default:
            return <div>Unsupported question type</div>;
    }
};

const ExamView: React.FC<ExamViewProps> = ({ exam, student, onFinish }) => {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<string, any>>({});
  const [timeLeft, setTimeLeft] = useState(exam.duration * 60);
  const [policyAccepted, setPolicyAccepted] = useState(false);
  const [isConfirmModalOpen, setIsConfirmModalOpen] = useState(false);
  const [lowTimeAlertPlayed, setLowTimeAlertPlayed] = useState(false);
  
  const [warnings, setWarnings] = useState(0);
  const [isWarningModalOpen, setIsWarningModalOpen] = useState(false);
  const [warningMessage, setWarningMessage] = useState('');

  const examContainerRef = useRef<HTMLDivElement>(null);
  const isSubmittingRef = useRef(false);
  const LOCAL_STORAGE_KEY = `exam-answers-${exam.id}-${student.id}`;
  
  const stateRef = useRef({ onFinish, answers, warnings, isWarningModalOpen });
  stateRef.current = { onFinish, answers, warnings, isWarningModalOpen };

  const submitAndCleanup = useCallback(() => {
    isSubmittingRef.current = true;
    stateRef.current.onFinish(stateRef.current.answers);
    localStorage.removeItem(LOCAL_STORAGE_KEY);
    if (document.fullscreenElement) {
      document.exitFullscreen().catch(err => console.error("Could not exit fullscreen", err));
    }
  }, [LOCAL_STORAGE_KEY]);
  const submitAndCleanupRef = useRef(submitAndCleanup);
  submitAndCleanupRef.current = submitAndCleanup;

  const handleInfraction = useCallback((message: string) => {
    // Prevent multiple warnings from stacking up
    if (stateRef.current.isWarningModalOpen) return;

    const newWarningCount = stateRef.current.warnings + 1;
    setWarnings(newWarningCount);
    setWarningMessage(message);
    
    if (newWarningCount >= 3) {
        submitAndCleanupRef.current();
    } else {
        setIsWarningModalOpen(true);
    }
  }, []);
  const handleInfractionRef = useRef(handleInfraction);
  handleInfractionRef.current = handleInfraction;


  // Load saved answers on mount
  useEffect(() => {
    const savedAnswers = localStorage.getItem(LOCAL_STORAGE_KEY);
    if (savedAnswers) {
        try {
            setAnswers(JSON.parse(savedAnswers));
        } catch (e) {
            console.error("Failed to parse saved answers.", e);
            localStorage.removeItem(LOCAL_STORAGE_KEY);
        }
    }
  }, [LOCAL_STORAGE_KEY]);

  // Auto-save answers every 10 seconds
  useEffect(() => {
    if (!policyAccepted) return;
    const autoSaveInterval = setInterval(() => {
        localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(stateRef.current.answers));
    }, 10000);
    return () => clearInterval(autoSaveInterval);
  }, [policyAccepted, LOCAL_STORAGE_KEY]);


  // Timer logic with audio alert
  useEffect(() => {
    if (!policyAccepted) return;

    const playLowTimeAlert = () => {
        const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
        if (!audioContext) return;
        const oscillator = audioContext.createOscillator();
        const gainNode = audioContext.createGain();
        oscillator.connect(gainNode);
        gainNode.connect(audioContext.destination);
        oscillator.type = 'sine';
        oscillator.frequency.setValueAtTime(880, audioContext.currentTime);
        gainNode.gain.setValueAtTime(0.5, audioContext.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.0001, audioContext.currentTime + 1);
        oscillator.start(audioContext.currentTime);
        oscillator.stop(audioContext.currentTime + 1);
    };

    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          clearInterval(timer);
          submitAndCleanupRef.current();
          return 0;
        }
        if (prev > 59 && prev <= 60 && !lowTimeAlertPlayed) {
            playLowTimeAlert();
            setLowTimeAlertPlayed(true);
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [policyAccepted, lowTimeAlertPlayed]);
  
  // Proctoring and Lockdown Listeners
  useEffect(() => {
    if (!policyAccepted) return;

    // 1. Tab switching
    const handleVisibilityChange = () => {
        if (document.hidden) {
            handleInfractionRef.current('You have switched away from the exam tab. This is not permitted.');
        }
    };
    
    // 2. Fullscreen enforcement
    const handleFullscreenChange = () => {
        if (!document.fullscreenElement && !isSubmittingRef.current) {
            handleInfractionRef.current('You have exited full-screen mode. This is not permitted.');
        }
    };
    
    // 3. Prevent copy, paste, cut, context menu (right-click)
    const preventAction = (e: Event, type: string) => {
        e.preventDefault();
        handleInfractionRef.current(`Action blocked: ${type} is not allowed during the exam.`);
    };
    const handleCopy = (e: Event) => preventAction(e, 'Copying');
    const handlePaste = (e: Event) => preventAction(e, 'Pasting');
    const handleCut = (e: Event) => preventAction(e, 'Cutting');
    const handleContextMenu = (e: Event) => preventAction(e, 'Right-clicking');

    // 4. Attempt to block screenshots
    const handleScreenshotAttempt = (e: KeyboardEvent) => {
        if (e.key === 'PrintScreen') {
            e.preventDefault();
            handleInfractionRef.current('Taking screenshots is not allowed during the exam.');
        }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    document.addEventListener('fullscreenchange', handleFullscreenChange);
    document.addEventListener('keydown', handleScreenshotAttempt);
    
    const examContainer = examContainerRef.current;
    if (examContainer) {
        examContainer.addEventListener('copy', handleCopy);
        examContainer.addEventListener('paste', handlePaste);
        examContainer.addEventListener('cut', handleCut);
        examContainer.addEventListener('contextmenu', handleContextMenu);
    }

    return () => {
        document.removeEventListener('visibilitychange', handleVisibilityChange);
        document.removeEventListener('fullscreenchange', handleFullscreenChange);
        document.removeEventListener('keydown', handleScreenshotAttempt);
        if (examContainer) {
            examContainer.removeEventListener('copy', handleCopy);
            examContainer.removeEventListener('paste', handlePaste);
            examContainer.removeEventListener('cut', handleCut);
            examContainer.removeEventListener('contextmenu', handleContextMenu);
        }
    };
  }, [policyAccepted]);
  
  const enterFullScreen = async () => {
      const elem = examContainerRef.current;
      if (elem?.requestFullscreen) {
          await elem.requestFullscreen().catch(err => console.error(err));
      }
  };
  
  const handlePolicyAccept = () => {
    setPolicyAccepted(true);
    enterFullScreen();
  };

  const handleAnswer = (answer: any) => {
    setAnswers(prev => ({
      ...prev,
      [exam.questions[currentQuestionIndex].id]: answer,
    }));
  };

  const goToQuestion = (index: number) => {
    if (index >= 0 && index < exam.questions.length) {
      setCurrentQuestionIndex(index);
    }
  };

  const handleFinalSubmit = () => {
    setIsConfirmModalOpen(false);
    submitAndCleanupRef.current();
  }
  
  if (!policyAccepted) {
    return <ExamPolicyModal onAccept={handlePolicyAccept} />;
  }
  
  const currentQuestion = exam.questions[currentQuestionIndex];
  const totalQuestions = exam.questions.length;
  const answeredQuestions = Object.keys(answers).filter(key => answers[key] !== null && answers[key] !== '' && (!Array.isArray(answers[key]) || answers[key].some(item => item && item.trim() !== ''))).length;

  return (
    <>
      <AudioProctor onInfraction={() => handleInfractionRef.current('Loud noise detected. Please maintain a quiet environment.')} />
      <TabSwitchWarningModal
        isOpen={isWarningModalOpen}
        onClose={() => {
            setIsWarningModalOpen(false);
            setWarningMessage('');
        }}
        warnings={warnings}
        message={warningMessage}
      />
      <ConfirmSubmitModal
        isOpen={isConfirmModalOpen}
        onClose={() => setIsConfirmModalOpen(false)}
        onConfirm={handleFinalSubmit}
        answeredQuestions={answeredQuestions}
        totalQuestions={totalQuestions}
        timeLeft={timeLeft}
      />
      <div ref={examContainerRef} className="flex flex-col h-screen bg-slate-100 dark:bg-slate-900 text-slate-900 dark:text-slate-100 p-4 sm:p-6 fullscreen:p-8">
        <header className="flex-shrink-0 bg-white dark:bg-slate-800 rounded-lg shadow-md p-4 mb-4">
          <div className="flex flex-col sm:flex-row justify-between items-center">
            <h1 className="text-2xl font-bold text-indigo-700 dark:text-indigo-400">{exam.title}</h1>
            <Timer timeLeft={timeLeft} />
          </div>
          <ProgressBar current={answeredQuestions} total={totalQuestions} />
        </header>

        <div className="flex-grow flex flex-col md:flex-row gap-4 overflow-hidden">
          <aside className="w-full md:w-1/4 lg:w-1/5 flex-shrink-0 bg-white dark:bg-slate-800 rounded-lg shadow-md p-4 flex flex-col">
            <h2 className="text-lg font-semibold mb-3">Questions</h2>
            <div className="grid grid-cols-4 sm:grid-cols-5 md:grid-cols-4 gap-2">
              {exam.questions.map((q, index) => (
                <button
                  key={q.id}
                  onClick={() => goToQuestion(index)}
                  className={`flex items-center justify-center w-10 h-10 rounded-full text-sm font-bold transition ${
                    index === currentQuestionIndex
                      ? 'bg-indigo-600 text-white ring-2 ring-offset-2 ring-indigo-500 ring-offset-slate-100 dark:ring-offset-slate-800'
                      : answers[q.id] ? 'bg-green-500 text-white' : 'bg-slate-200 dark:bg-slate-700'
                  }`}
                >
                  {index + 1}
                </button>
              ))}
            </div>
          </aside>

          <main className="flex-grow bg-white dark:bg-slate-800 rounded-lg shadow-md p-6 flex flex-col overflow-y-auto">
              <div className="flex-grow">
                <h2 className="text-xl font-semibold mb-1">Question {currentQuestionIndex + 1} of {totalQuestions}</h2>
                <p className="lg mb-6 whitespace-pre-wrap">{currentQuestion.text}</p>
                <QuestionCard
                  question={currentQuestion}
                  answer={answers[currentQuestion.id] || null}
                  onAnswer={handleAnswer}
                />
              </div>

              <div className="flex justify-between mt-8 border-t border-slate-200 dark:border-slate-700 pt-6">
                <button
                  onClick={() => goToQuestion(currentQuestionIndex - 1)}
                  disabled={currentQuestionIndex === 0}
                  className="px-6 py-2 bg-slate-300 dark:bg-slate-600 rounded-lg hover:bg-slate-400 dark:hover:bg-slate-500 disabled:opacity-50 disabled:cursor-not-allowed transition"
                >
                  Previous
                </button>
                {currentQuestionIndex === totalQuestions - 1 ? (
                  <button
                      onClick={() => setIsConfirmModalOpen(true)}
                      className="px-6 py-2 bg-green-600 text-white font-semibold rounded-lg hover:bg-green-700 transition"
                  >
                      Submit Exam
                  </button>
                ) : (
                  <button
                      onClick={() => goToQuestion(currentQuestionIndex + 1)}
                      disabled={currentQuestionIndex === totalQuestions - 1}
                      className="px-6 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed transition"
                  >
                      Next
                  </button>
                )}
              </div>
          </main>
        </div>
      </div>
    </>
  );
};

export default ExamView;