import React, { useState } from 'react';

interface ExamPolicyModalProps {
  onAccept: () => void;
}

const ExamPolicyModal: React.FC<ExamPolicyModalProps> = ({ onAccept }) => {
  const [agreed, setAgreed] = useState(false);

  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50">
      <div className="bg-white dark:bg-slate-800 rounded-lg shadow-xl p-8 max-w-lg w-full transform transition-all animate-fade-in-up">
        <h2 className="text-2xl font-bold text-slate-900 dark:text-white mb-4">Exam Policies and Instructions</h2>
        <ul className="list-disc list-inside space-y-3 text-slate-700 dark:text-slate-300 mb-6">
          <li>The exam must be taken in full-screen mode. Exiting full-screen will trigger a warning.</li>
          <li>Switching to other tabs or applications is not permitted and will result in a warning.</li>
          <li>Your microphone will be enabled to monitor for ambient noise. Sustained loud noises will also trigger a warning.</li>
          <li>Copying, pasting, taking screenshots, or right-clicking is disabled and will be flagged as a violation.</li>
          <li>Your progress is auto-saved every 10 seconds.</li>
          <li>Receiving 3 warnings for any violation will cause the exam to be submitted automatically.</li>
          <li>No cheating or external help is allowed. Each student has only one attempt.</li>
        </ul>
        <div className="flex items-center mb-6">
          <input
            id="agree"
            type="checkbox"
            checked={agreed}
            onChange={() => setAgreed(!agreed)}
            className="h-5 w-5 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
          />
          <label htmlFor="agree" className="ml-3 block text-md text-slate-900 dark:text-slate-200">
            I understand and agree to all exam policies.
          </label>
        </div>
        <button
          onClick={onAccept}
          disabled={!agreed}
          className="w-full py-3 px-4 bg-indigo-600 text-white font-semibold rounded-lg hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:bg-indigo-400 disabled:cursor-not-allowed transition"
        >
          Start Exam
        </button>
      </div>
    </div>
  );
};

export default ExamPolicyModal;