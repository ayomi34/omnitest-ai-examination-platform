import React, { useState } from 'react';
import { Question, QuestionType } from '../../types';
import { generateQuestionsFromText, QuestionGenerationParams } from '../../services/geminiService';
import Modal from '../shared/Modal';
import Spinner from '../shared/Spinner';

interface GenerateQuestionsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAppend: (questions: Omit<Question, 'id'>[]) => void;
}

const GenerateQuestionsModal: React.FC<GenerateQuestionsModalProps> = ({ isOpen, onClose, onAppend }) => {
  const [params, setParams] = useState<Omit<QuestionGenerationParams, 'text'>>({ count: 5, type: QuestionType.MCQ });
  const [studyText, setStudyText] = useState('');
  const [generatedQuestions, setGeneratedQuestions] = useState<Omit<Question, 'id'>[]>([]);
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleGenerate = async () => {
    if (!studyText.trim()) {
      setError('Please provide some study material text.');
      return;
    }
    setIsLoading(true);
    setError('');
    setGeneratedQuestions([]);

    const result = await generateQuestionsFromText({ ...params, text: studyText });
    if (result) {
      setGeneratedQuestions(result);
    } else {
      setError('Failed to generate questions. The AI model might be unavailable or the request failed. Please try again.');
    }
    setIsLoading(false);
  };
  
  const handleAddQuestions = () => {
    onAppend(generatedQuestions);
    onClose();
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Generate Questions with AI">
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">Study Material</label>
          <textarea
            value={studyText}
            onChange={(e) => setStudyText(e.target.value)}
            rows={8}
            placeholder="Paste the content you want to create questions from..."
            className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
          />
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">Number of Questions</label>
            <input
              type="number"
              value={params.count}
              onChange={(e) => setParams(p => ({ ...p, count: parseInt(e.target.value, 10) || 1 }))}
              min="1"
              max="20"
              className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 shadow-sm"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">Question Type</label>
            <select
              value={params.type}
              onChange={(e) => setParams(p => ({ ...p, type: e.target.value as QuestionType }))}
              className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 shadow-sm"
            >
              <option value={QuestionType.MCQ}>Multiple Choice</option>
              <option value={QuestionType.Essay}>Essay</option>
              <option value={QuestionType.FillInTheBlank}>Fill in the Blank</option>
            </select>
          </div>
        </div>
        
        <div className="text-center">
            <button onClick={handleGenerate} disabled={isLoading} className="w-full md:w-auto px-6 py-2 bg-purple-600 text-white font-semibold rounded-lg hover:bg-purple-700 disabled:bg-purple-400 flex items-center justify-center gap-2 mx-auto">
                {isLoading ? <Spinner size="sm" /> : <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M11.3 1.046A1 1 0 0112 2v5h4a1 1 0 01.82 1.573l-7 10A1 1 0 018 18v-5H4a1 1 0 01-.82-1.573l7-10a1 1 0 011.12-.38z" clipRule="evenodd" /></svg>}
                Generate
            </button>
        </div>

        {isLoading && <div className="text-center p-8"><Spinner text="AI is thinking... Please wait." /></div>}
        {error && <p className="text-red-500 bg-red-100 dark:bg-red-900 p-3 rounded-lg">{error}</p>}
        
        {generatedQuestions.length > 0 && (
          <div className="mt-4">
            <h4 className="font-bold mb-2">AI-Generated Questions (Preview)</h4>
            <div className="max-h-64 overflow-y-auto border dark:border-slate-600 rounded-lg p-2 space-y-2 bg-slate-50 dark:bg-slate-900">
              {generatedQuestions.map((q, i) => (
                <div key={i} className="p-2 border-b dark:border-slate-700 text-sm">
                  <p><strong>{i+1}. {q.text}</strong></p>
                  {q.type === QuestionType.MCQ && (
                    <ul className="list-disc list-inside pl-4 text-slate-600 dark:text-slate-400">
                      {q.options?.map((opt, idx) => <li key={idx} className={opt === q.correctAnswer ? 'font-bold text-green-600 dark:text-green-400' : ''}>{opt}</li>)}
                    </ul>
                  )}
                   {q.type === QuestionType.FillInTheBlank && <p className="text-green-600 dark:text-green-400">Answers: {(q.correctAnswer as string[])?.join(', ')}</p>}
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="flex justify-end gap-4 pt-6 border-t border-slate-200 dark:border-slate-700">
          <button type="button" onClick={onClose} className="px-6 py-2 bg-slate-200 dark:bg-slate-600 rounded-lg hover:bg-slate-300 dark:hover:bg-slate-500 transition">Cancel</button>
          <button type="button" onClick={handleAddQuestions} disabled={generatedQuestions.length === 0} className="px-6 py-2 bg-green-600 text-white font-semibold rounded-lg hover:bg-green-700 transition disabled:bg-green-400">
            Add {generatedQuestions.length} Questions
          </button>
        </div>
      </div>
    </Modal>
  );
};

export default GenerateQuestionsModal;
