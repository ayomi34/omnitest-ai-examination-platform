import React, { useMemo, useState } from 'react';
import { Exam, Submission, Question } from '../../types';

interface ExamAnalyticsProps {
  exams: Exam[];
  submissions: Submission[];
}

const StatCard: React.FC<{ title: string; value: string | number; icon: React.ReactNode }> = ({ title, value, icon }) => (
    <div className="bg-white dark:bg-slate-800 p-4 rounded-lg flex items-center gap-4 shadow-sm">
        <div className="bg-indigo-100 dark:bg-indigo-800 p-3 rounded-full">{icon}</div>
        <div>
            <div className="text-slate-500 dark:text-slate-400 text-sm">{title}</div>
            <div className="text-2xl font-bold text-slate-900 dark:text-white">{value}</div>
        </div>
    </div>
);

const BarChart: React.FC<{ data: { label: string; value: number }[] }> = ({ data }) => {
    const maxValue = Math.max(...data.map(d => d.value), 0);
    return (
        <div className="w-full p-4 bg-white dark:bg-slate-800 rounded-lg shadow-sm">
            <h4 className="font-bold mb-4 text-center">Average Score by Exam</h4>
            <div className="flex justify-around items-end h-48 gap-4">
                {data.map(({ label, value }) => (
                    <div key={label} className="flex flex-col items-center flex-1">
                        <div className="text-sm font-bold">{value.toFixed(1)}%</div>
                        <div
                            className="w-full bg-indigo-500 rounded-t-md hover:bg-indigo-600 transition-colors"
                            style={{ height: `${(value / (maxValue || 100)) * 100}%` }}
                            title={`${label}: ${value.toFixed(1)}%`}
                        ></div>
                        <div className="text-xs text-slate-600 dark:text-slate-400 mt-1 truncate w-full text-center" title={label}>{label}</div>
                    </div>
                ))}
            </div>
        </div>
    );
};

const DoughnutChart: React.FC<{ percentage: number; color: string }> = ({ percentage, color }) => (
    <div className="relative w-24 h-24 flex items-center justify-center">
        <svg className="w-full h-full" viewBox="0 0 36 36">
            <path
                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                className="text-slate-200 dark:text-slate-700"
                fill="none"
                stroke="currentColor"
                strokeWidth="3"
            />
            <path
                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                fill="none"
                stroke={color}
                strokeWidth="3"
                strokeDasharray={`${percentage}, 100`}
                strokeLinecap="round"
                transform="rotate(-90 18 18)"
            />
        </svg>
        <div className="absolute text-xl font-bold">{percentage.toFixed(0)}%</div>
    </div>
);

const QuestionDifficultyList: React.FC<{ questions: any[], title: string }> = ({ questions, title }) => (
    <div>
        <h5 className="font-bold text-md mb-2">{title}</h5>
        <ul className="space-y-2 text-sm">
            {questions.map(q => (
                <li key={q.id} className="p-2 bg-slate-50 dark:bg-slate-900 rounded-md">
                    <p className="truncate font-medium">{q.text}</p>
                    <p className="text-slate-500 dark:text-slate-400">Correctness: <span className="font-bold">{q.correctPercentage.toFixed(0)}%</span></p>
                </li>
            ))}
        </ul>
    </div>
);

const ExamAnalytics: React.FC<ExamAnalyticsProps> = ({ exams, submissions }) => {
    const [selectedExamId, setSelectedExamId] = useState<string | null>(exams.length > 0 ? exams[0].id : null);

    const analyticsData = useMemo(() => {
        if (exams.length === 0) return null;

        let totalScore = 0;
        let totalPossible = 0;

        const examStats = exams.map(exam => {
            const examSubmissions = submissions.filter(s => s.examId === exam.id);
            const totalPoints = exam.questions.reduce((sum, q) => sum + (q.points || 0), 0);
            
            if (examSubmissions.length === 0) {
                return { exam, averageScore: 0, passRate: 0, questionPerformance: [] };
            }

            let examTotalScore = 0;
            let passedCount = 0;
            const questionCorrectCounts: Record<string, number> = {};
            exam.questions.forEach(q => { questionCorrectCounts[q.id] = 0; });

            examSubmissions.forEach(sub => {
                const score = sub.finalScore ?? 0;
                examTotalScore += score;
                if (totalPoints > 0 && (score / totalPoints) >= 0.5) {
                    passedCount++;
                }
                Object.entries(sub.grades).forEach(([questionId, grade]) => {
                    if (grade.score > 0) {
                        questionCorrectCounts[questionId] = (questionCorrectCounts[questionId] || 0) + 1;
                    }
                });
            });

            totalScore += examTotalScore;
            totalPossible += totalPoints * examSubmissions.length;
            
            const questionPerformance = exam.questions.map(q => ({
                ...q,
                correctPercentage: (questionCorrectCounts[q.id] / examSubmissions.length) * 100
            })).sort((a,b) => a.correctPercentage - b.correctPercentage);

            return {
                exam,
                averageScore: totalPoints > 0 ? (examTotalScore / examSubmissions.length / totalPoints) * 100 : 0,
                passRate: (passedCount / examSubmissions.length) * 100,
                questionPerformance,
            };
        });

        const overallAverage = totalPossible > 0 ? (totalScore / totalPossible) * 100 : 0;
        
        return {
            overall: {
                totalExams: exams.length,
                totalSubmissions: submissions.length,
                averageScore: overallAverage,
            },
            byExam: examStats,
        };
    }, [exams, submissions]);
    
    const selectedExamData = analyticsData?.byExam.find(e => e.exam.id === selectedExamId);

    if (!analyticsData) {
        return (
            <div className="text-center p-8 text-slate-500 bg-white dark:bg-slate-800 rounded-lg shadow-sm">
                No exam data available to generate analytics.
            </div>
        );
    }
    
    const barChartData = analyticsData.byExam.map(e => ({ label: e.exam.title, value: e.averageScore }));

    return (
        <div className="space-y-6">
            {/* Overall Stats */}
            <section>
                <h3 className="text-lg font-bold mb-3">Overall Performance</h3>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <StatCard title="Total Exams" value={analyticsData.overall.totalExams} icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-indigo-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" /></svg>} />
                    <StatCard title="Total Submissions" value={analyticsData.overall.totalSubmissions} icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-indigo-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>} />
                    <StatCard title="Avg. Score" value={`${analyticsData.overall.averageScore.toFixed(1)}%`} icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-indigo-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" /></svg>} />
                </div>
            </section>
            
            {/* Bar Chart */}
            <section>
                <BarChart data={barChartData} />
            </section>

            {/* Detailed Breakdown */}
            <section className="border-t dark:border-slate-700 pt-6">
                <h3 className="text-lg font-bold mb-3">Detailed Breakdown by Exam</h3>
                <select
                    value={selectedExamId || ''}
                    onChange={(e) => setSelectedExamId(e.target.value)}
                    className="w-full p-2 rounded-md border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 shadow-sm"
                >
                    {exams.map(e => <option key={e.id} value={e.id}>{e.title}</option>)}
                </select>

                {selectedExamData && (
                    <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-6">
                        <div className="md:col-span-1 flex flex-col items-center justify-center p-4 bg-white dark:bg-slate-800 rounded-lg shadow-sm">
                           <h4 className="font-bold mb-2">Pass / Fail Rate</h4>
                           <div className="flex items-center gap-4">
                               <div>
                                   <DoughnutChart percentage={selectedExamData.passRate} color="rgb(34 197 94)" />
                                   <p className="text-center text-sm mt-1">Pass</p>
                               </div>
                               <div>
                                   <DoughnutChart percentage={100 - selectedExamData.passRate} color="rgb(239 68 68)" />
                                   <p className="text-center text-sm mt-1">Fail</p>
                               </div>
                           </div>
                        </div>
                        <div className="md:col-span-2 grid grid-cols-1 sm:grid-cols-2 gap-4 bg-white dark:bg-slate-800 rounded-lg shadow-sm p-4">
                           <QuestionDifficultyList questions={selectedExamData.questionPerformance.slice(0, 3)} title="Hardest Questions" />
                           <QuestionDifficultyList questions={[...selectedExamData.questionPerformance].reverse().slice(0, 3)} title="Easiest Questions" />
                        </div>
                    </div>
                )}
            </section>
        </div>
    );
};

export default ExamAnalytics;