import React, { useState, useMemo } from 'react';
import { User, Exam, Submission } from '../../types';
import ExamAnalytics from './ExamAnalytics';
import UserForm from '../admin/UserForm';
import ImportStudentsModal from '../shared/ImportStudentsModal';

interface TeacherDashboardProps {
  teacher: User;
  exams: Exam[];
  submissions: Submission[];
  onLogout: () => void;
  onAddNewExam: () => void;
  onEditExam: (exam: Exam) => void;
  onGradeExam: (exam: Exam) => void;
  onDeleteExam: (examId: string) => void;
  onUpdateUser: (user: User) => void;
  onAddUsersBatch: (usersData: { fullName: string }[]) => (User & { plainPassword?: string })[];
}

type TeacherView = 'exams' | 'submissions' | 'analytics' | 'students';

const NavItem: React.FC<{
    icon: React.ReactNode;
    label: string;
    isActive: boolean;
    onClick: () => void;
}> = ({ icon, label, isActive, onClick }) => (
    <button
        onClick={onClick}
        className={`flex items-center w-full px-4 py-3 text-left rounded-lg transition-colors ${
            isActive
                ? 'bg-indigo-600 text-white shadow-md'
                : 'text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
        }`}
    >
        {icon}
        <span className="ml-3 font-semibold">{label}</span>
    </button>
);

const ExamsView: React.FC<Pick<TeacherDashboardProps, 'exams' | 'onAddNewExam' | 'onGradeExam' | 'onEditExam' | 'onDeleteExam'>> = 
({ exams, onAddNewExam, onGradeExam, onEditExam, onDeleteExam }) => (
    <div>
        <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold text-slate-800 dark:text-slate-200">Your Exams</h2>
            <button
                onClick={onAddNewExam}
                className="px-4 py-2 bg-indigo-600 text-white font-semibold rounded-lg hover:bg-indigo-700 transition-colors shadow-md"
            >
                + Create New Exam
            </button>
        </div>
        <div className="bg-white dark:bg-slate-800 rounded-xl shadow-lg overflow-hidden">
            <div className="overflow-x-auto">
                <table className="w-full text-left">
                    <thead className="bg-slate-50 dark:bg-slate-700">
                        <tr>
                            <th className="p-4 font-semibold">Title</th>
                            <th className="p-4 font-semibold">Subject</th>
                            <th className="p-4 font-semibold">Questions</th>
                            <th className="p-4 font-semibold">Duration</th>
                            <th className="p-4 font-semibold text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {exams.map(exam => (
                            <tr key={exam.id} className="border-b dark:border-slate-700 last:border-b-0">
                                <td className="p-4 font-medium">{exam.title}</td>
                                <td className="p-4">{exam.subject}</td>
                                <td className="p-4">{exam.questions.length}</td>
                                <td className="p-4">{exam.duration} mins</td>
                                <td className="p-4 text-right space-x-2">
                                    <button onClick={() => onGradeExam(exam)} className="px-3 py-1 text-sm font-medium text-white bg-green-600 rounded-md hover:bg-green-700">Grade</button>
                                    <button onClick={() => onEditExam(exam)} className="px-3 py-1 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700">Edit</button>
                                    <button onClick={() => onDeleteExam(exam.id)} className="px-3 py-1 text-sm font-medium text-white bg-red-600 rounded-md hover:bg-red-700">Delete</button>
                                </td>
                            </tr>
                        ))}
                        {exams.length === 0 && (
                            <tr>
                                <td colSpan={5} className="p-8 text-center text-slate-500">You haven't created any exams yet.</td>
                            </tr>
                        )}
                    </tbody>
                </table>
            </div>
        </div>
    </div>
);

const SubmissionsView: React.FC<{ submissions: Submission[], exams: Exam[] }> = ({ submissions, exams }) => {
    const [sortConfig, setSortConfig] = useState<{ key: keyof Submission | 'examTitle', direction: 'asc' | 'desc' } | null>(null);
    
    const examMap = useMemo(() => new Map(exams.map(exam => [exam.id, exam.title])), [exams]);

    const sortedSubmissions = useMemo(() => {
        let sortableItems = [...submissions];
        if (sortConfig !== null) {
            sortableItems.sort((a, b) => {
                let aValue: any;
                let bValue: any;

                if (sortConfig.key === 'examTitle') {
                    aValue = examMap.get(a.examId) || '';
                    bValue = examMap.get(b.examId) || '';
                } else {
                    aValue = a[sortConfig.key as keyof Submission];
                    bValue = b[sortConfig.key as keyof Submission];
                }
                
                if (aValue < bValue) {
                    return sortConfig.direction === 'asc' ? -1 : 1;
                }
                if (aValue > bValue) {
                    return sortConfig.direction === 'asc' ? 1 : -1;
                }
                return 0;
            });
        }
        return sortableItems;
    }, [submissions, sortConfig, examMap]);

    const requestSort = (key: keyof Submission | 'examTitle') => {
        let direction: 'asc' | 'desc' = 'asc';
        if (sortConfig && sortConfig.key === key && sortConfig.direction === 'asc') {
            direction = 'desc';
        }
        setSortConfig({ key, direction });
    };

    const getSortIndicator = (key: keyof Submission | 'examTitle') => {
        if (!sortConfig || sortConfig.key !== key) return null;
        return sortConfig.direction === 'asc' ? '▲' : '▼';
    };

    return (
        <div>
            <h2 className="text-2xl font-bold mb-6 text-slate-800 dark:text-slate-200">All Submissions</h2>
            <div className="bg-white dark:bg-slate-800 rounded-xl shadow-lg overflow-hidden">
                <div className="overflow-x-auto">
                    <table className="w-full text-left">
                        <thead className="bg-slate-50 dark:bg-slate-700">
                            <tr>
                                <th className="p-4 font-semibold cursor-pointer" onClick={() => requestSort('studentName')}>Student {getSortIndicator('studentName')}</th>
                                <th className="p-4 font-semibold cursor-pointer" onClick={() => requestSort('examTitle')}>Exam {getSortIndicator('examTitle')}</th>
                                <th className="p-4 font-semibold cursor-pointer" onClick={() => requestSort('finalScore')}>Score {getSortIndicator('finalScore')}</th>
                                <th className="p-4 font-semibold cursor-pointer" onClick={() => requestSort('submittedAt')}>Date {getSortIndicator('submittedAt')}</th>
                            </tr>
                        </thead>
                        <tbody>
                            {sortedSubmissions.map(sub => (
                                <tr key={sub.id} className="border-b dark:border-slate-700 last:border-b-0">
                                    <td className="p-4 font-medium">{sub.studentName}</td>
                                    <td className="p-4">{examMap.get(sub.examId) || 'Unknown Exam'}</td>
                                    <td className="p-4">{sub.finalScore ?? 'N/A'}</td>
                                    <td className="p-4">{new Date(sub.submittedAt).toLocaleString()}</td>
                                </tr>
                            ))}
                             {sortedSubmissions.length === 0 && (
                                <tr>
                                    <td colSpan={4} className="p-8 text-center text-slate-500">No student submissions found.</td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};

const StudentsView: React.FC<{ onImportClick: () => void }> = ({ onImportClick }) => (
    <div>
        <div className="flex justify-between items-center mb-6 flex-wrap gap-2">
            <h2 className="text-2xl font-bold text-slate-800 dark:text-slate-200">Manage Students</h2>
            <button
                onClick={onImportClick}
                className="px-4 py-2 bg-indigo-600 text-white font-semibold rounded-lg hover:bg-indigo-700 transition-colors shadow-md"
            >
                + Import Students from File
            </button>
        </div>
        <div className="bg-white dark:bg-slate-800 rounded-xl shadow-lg p-8 text-center">
            <svg xmlns="http://www.w3.org/2000/svg" className="mx-auto h-12 w-12 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" /></svg>
            <h3 className="mt-4 text-lg font-medium text-slate-900 dark:text-white">Quickly Add Students</h3>
            <p className="mt-2 text-sm text-slate-500 dark:text-slate-400">
                Use the import feature to add new student accounts. Upload an Excel or CSV file with student names, and the system will generate unique login credentials for them.
            </p>
        </div>
    </div>
);


const TeacherDashboard: React.FC<TeacherDashboardProps> = ({ teacher, exams, submissions, onLogout, onAddNewExam, onEditExam, onGradeExam, onDeleteExam, onUpdateUser, onAddUsersBatch }) => {
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  const [activeView, setActiveView] = useState<TeacherView>('exams');
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  
  const teacherSubmissions = submissions.filter(submission => 
    exams.some(exam => exam.id === submission.examId)
  );
  
  const renderContent = () => {
      switch (activeView) {
          case 'exams':
              return <ExamsView exams={exams} onAddNewExam={onAddNewExam} onGradeExam={onGradeExam} onEditExam={onEditExam} onDeleteExam={onDeleteExam} />;
          case 'submissions':
              return <SubmissionsView submissions={teacherSubmissions} exams={exams} />;
          case 'analytics':
              return <ExamAnalytics exams={exams} submissions={teacherSubmissions} />;
          case 'students':
              return <StudentsView onImportClick={() => setIsImportModalOpen(true)} />;
          default:
              return null;
      }
  };

  return (
    <>
      <div className="min-h-screen bg-slate-100 dark:bg-slate-900 text-slate-800 dark:text-slate-200">
          <div className="container mx-auto p-4 sm:p-6 lg:p-8">
              <header className="flex justify-between items-center mb-8 flex-wrap gap-4">
                  <div>
                      <h1 className="text-4xl font-extrabold text-slate-900 dark:text-white">Welcome, {teacher.fullName}!</h1>
                      <p className="text-slate-600 dark:text-slate-400 mt-1">Your teacher dashboard is ready.</p>
                  </div>
                  <div className="flex items-center gap-4">
                      <button
                          onClick={() => setIsProfileModalOpen(true)}
                          className="p-2 rounded-full hover:bg-slate-200 dark:hover:bg-slate-700 transition"
                          title="Edit Profile"
                      >
                           <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg>
                      </button>
                      <button
                          onClick={onLogout}
                          className="px-4 py-2 bg-red-600 text-white font-semibold rounded-lg hover:bg-red-700 transition-colors shadow-md"
                      >
                          Logout
                      </button>
                  </div>
              </header>

              <main className="flex flex-col md:flex-row gap-8">
                <aside className="w-full md:w-1/4 lg:w-1/5">
                    <nav className="space-y-2">
                        <NavItem
                            label="Exams"
                            icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path d="M9 2a1 1 0 000 2h2a1 1 0 100-2H9z" /><path fillRule="evenodd" d="M4 5a2 2 0 012-2h8a2 2 0 012 2v10a2 2 0 01-2 2H6a2 2 0 01-2-2V5zm3 4a1 1 0 000 2h4a1 1 0 100-2H7zm0 4a1 1 0 100 2h4a1 1 0 100-2H7z" clipRule="evenodd" /></svg>}
                            isActive={activeView === 'exams'}
                            onClick={() => setActiveView('exams')}
                        />
                        <NavItem
                            label="Submissions"
                            icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" /></svg>}
                            isActive={activeView === 'submissions'}
                            onClick={() => setActiveView('submissions')}
                        />
                        <NavItem
                            label="Analytics"
                            icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path d="M2 10a8 8 0 018-8v8h8a8 8 0 11-16 0z" /><path d="M12 2.252A8.014 8.014 0 0117.748 12H12V2.252z" /></svg>}
                            isActive={activeView === 'analytics'}
                            onClick={() => setActiveView('analytics')}
                        />
                        <NavItem
                            label="Students"
                            icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path d="M9 6a3 3 0 11-6 0 3 3 0 016 0zM17 6a3 3 0 11-6 0 3 3 0 016 0zM12.93 17c.046-.327.07-.66.07-1a6.97 6.97 0 00-1.5-4.33A5 5 0 0119 16v1h-6.07zM6 11a5 5 0 015 5v1H1v-1a5 5 0 015-5z" /></svg>}
                            isActive={activeView === 'students'}
                            onClick={() => setActiveView('students')}
                        />
                    </nav>
                </aside>
                <div className="flex-1">
                    {renderContent()}
                </div>
              </main>
          </div>
      </div>
      
      {isProfileModalOpen && (
        <UserForm
          existingUser={teacher}
          onSave={(user) => {
            onUpdateUser(user as User);
            setIsProfileModalOpen(false);
          }}
          onCancel={() => setIsProfileModalOpen(false)}
          isProfileEdit={true}
        />
      )}
      {isImportModalOpen && (
          <ImportStudentsModal
              isOpen={isImportModalOpen}
              onClose={() => setIsImportModalOpen(false)}
              onImport={onAddUsersBatch}
          />
      )}
    </>
  );
};

export default TeacherDashboard;