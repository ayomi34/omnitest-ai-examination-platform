import React from 'react';
import { Question, QuestionType } from '../../types';

interface QuestionEditorProps {
  question: Question;
  onSave: (question: Question) => void;
  onDelete: (questionId: string) => void;
  index: number;
}

const QuestionEditor: React.FC<QuestionEditorProps> = ({ question, onSave, onDelete, index }) => {
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    const newQuestionState = { ...question, [name]: value };

    if (name === 'type') {
        const newType = value as QuestionType;
        // Reset properties that are not relevant for the new type to ensure data integrity
        switch(newType) {
            case QuestionType.MCQ:
                newQuestionState.correctAnswer = (question.options && question.options.length > 0) ? question.options[0] : '';
                if (!newQuestionState.options || newQuestionState.options.length === 0) {
                    newQuestionState.options = ['', ''];
                }
                delete newQuestionState.rubric;
                break;
            case QuestionType.FillInTheBlank:
                const numBlanks = newQuestionState.text.split('___').length - 1;
                newQuestionState.correctAnswer = Array(numBlanks > 0 ? numBlanks : 0).fill('');
                delete newQuestionState.options;
                delete newQuestionState.rubric;
                break;
            case QuestionType.Essay:
                newQuestionState.rubric = '';
                delete newQuestionState.correctAnswer;
                delete newQuestionState.options;
                break;
        }
    }
    onSave(newQuestionState as Question);
  };

  const handlePointsChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onSave({ ...question, points: parseInt(e.target.value, 10) || 0 });
  }

  const handleOptionChange = (optionIndex: number, value: string) => {
    const newOptions = [...(question.options || [])];
    newOptions[optionIndex] = value;
    onSave({ ...question, options: newOptions });
  };
  
  const handleAddOption = () => {
      const newOptions = [...(question.options || []), ''];
      onSave({ ...question, options: newOptions });
  }

  const handleRemoveOption = (optionIndex: number) => {
      const newOptions = (question.options || []).filter((_, i) => i !== optionIndex);
      onSave({ ...question, options: newOptions });
  }

  const handleCorrectAnswerChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onSave({ ...question, correctAnswer: e.target.value });
  }

  const handleFillBlankAnswerChange = (answerIndex: number, value: string) => {
    const newAnswers = [...(question.correctAnswer as string[] || [])];
    newAnswers[answerIndex] = value;
    onSave({ ...question, correctAnswer: newAnswers });
  }
  
  const numBlanks = question.text.split('___').length - 1;

  return (
    <div className="p-4 border rounded-lg bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700">
        <div className="flex justify-between items-start mb-4">
            <h4 className="text-lg font-bold">Question {index + 1}</h4>
            <button type="button" onClick={() => onDelete(question.id)} className="text-red-500 hover:text-red-700">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
            </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="md:col-span-3">
                <label className="block text-sm font-medium">Question Text</label>
                <textarea name="text" value={question.text} onChange={handleInputChange} rows={3} className="mt-1 block w-full rounded-md shadow-sm sm:text-sm border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900" placeholder="For fill-in-the-blank, use ___ for blanks."></textarea>
            </div>
            <div className="md:col-span-1">
                <label className="block text-sm font-medium">Type</label>
                <select name="type" value={question.type} onChange={handleInputChange} className="mt-1 block w-full rounded-md shadow-sm sm:text-sm border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900">
                    <option value={QuestionType.MCQ}>Multiple Choice</option>
                    <option value={QuestionType.Essay}>Essay</option>
                    <option value={QuestionType.FillInTheBlank}>Fill in the Blank</option>
                </select>
                <label className="block text-sm font-medium mt-2">Points</label>
                <input type="number" name="points" value={question.points || 1} onChange={handlePointsChange} className="mt-1 block w-full rounded-md shadow-sm sm:text-sm border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900" min="0" />
            </div>
        </div>
        
        {question.type === QuestionType.MCQ && (
            <div className="mt-4 space-y-2">
                <h5 className="font-semibold">Options</h5>
                {question.options?.map((opt, i) => (
                    <div key={i} className="flex items-center gap-2">
                        <input type="radio" name={`correctAnswer_${question.id}`} checked={question.correctAnswer === opt} value={opt} onChange={handleCorrectAnswerChange} className="h-5 w-5 text-indigo-600"/>
                        <input type="text" value={opt} onChange={(e) => handleOptionChange(i, e.target.value)} className="block w-full rounded-md shadow-sm sm:text-sm border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900" />
                        <button type="button" onClick={() => handleRemoveOption(i)} className="text-red-500 hover:text-red-700 p-1">
                             <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12H9m12 0a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                        </button>
                    </div>
                ))}
                <button type="button" onClick={handleAddOption} className="text-sm text-indigo-600 hover:text-indigo-800">Add Option</button>
            </div>
        )}

        {question.type === QuestionType.Essay && (
             <div className="mt-4">
                <label className="block text-sm font-medium">Grading Rubric</label>
                <textarea name="rubric" value={question.rubric || ''} onChange={handleInputChange} rows={4} className="mt-1 block w-full rounded-md shadow-sm sm:text-sm border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900"></textarea>
            </div>
        )}

        {question.type === QuestionType.FillInTheBlank && numBlanks > 0 && (
             <div className="mt-4 space-y-2">
                <h5 className="font-semibold">Correct Answers</h5>
                {Array.from({ length: numBlanks }).map((_, i) => (
                    <div key={i} className="flex items-center gap-2">
                        <span className="font-mono">Blank {i + 1}:</span>
                        <input type="text" value={(question.correctAnswer as string[])?.[i] || ''} onChange={(e) => handleFillBlankAnswerChange(i, e.target.value)} className="block w-full rounded-md shadow-sm sm:text-sm border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900" />
                    </div>
                ))}
            </div>
        )}
    </div>
  );
};

export default QuestionEditor;