import React, { useState, useMemo } from 'react';
import { Exam, Submission, Question, QuestionType } from '../../types';
import { gradeEssayWithAI } from '../../services/geminiService';
import Spinner from '../shared/Spinner';

interface GradingViewProps {
  exam: Exam;
  submissions: Submission[];
  onBack: () => void;
  onSaveGrade: (submissionId: string, grades: Record<string, { score: number; feedback?: string }>, finalScore: number) => void;
}

const EssayGradingCard: React.FC<{
  question: Question,
  answer: string,
  grade: { score: number, feedback?: string } | undefined,
  onGradeChange: (grade: { score: number, feedback?: string }) => void
}> = ({ question, answer, grade, onGradeChange }) => {
    const [isLoading, setIsLoading] = useState(false);
    const [aiError, setAiError] = useState('');

    const handleAIGrade = async () => {
        setIsLoading(true);
        setAiError('');
        const result = await gradeEssayWithAI(question, answer);
        if (result) {
            onGradeChange({ score: result.score, feedback: result.feedback });
        } else {
            setAiError('Failed to get AI grading. Please try again.');
        }
        setIsLoading(false);
    };

    return (
        <div className="p-4 bg-slate-100 dark:bg-slate-900 rounded-lg mt-2">
             <h4 className="font-bold text-slate-800 dark:text-slate-200">Student's Answer:</h4>
             <p className="mt-1 mb-4 p-3 bg-white dark:bg-slate-800 rounded whitespace-pre-wrap">{answer || '(No answer provided)'}</p>
             
             {question.rubric && <>
                <h4 className="font-bold text-slate-800 dark:text-slate-200">Rubric:</h4>
                <p className="mt-1 mb-4 p-3 bg-white dark:bg-slate-800 rounded whitespace-pre-wrap">{question.rubric}</p>
             </>}

             <div className="flex justify-end mb-4">
                 <button onClick={handleAIGrade} disabled={isLoading} className="px-4 py-2 text-sm bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 disabled:bg-indigo-400 flex items-center gap-2">
                     {isLoading ? <Spinner size="sm" /> : <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M11.3 1.046A1 1 0 0112 2v5h4a1 1 0 01.82 1.573l-7 10A1 1 0 018 18v-5H4a1 1 0 01-.82-1.573l7-10a1 1 0 011.12-.38z" clipRule="evenodd" /></svg>}
                     Grade with AI
                 </button>
             </div>
             {aiError && <p className="text-red-500 text-sm mb-2">{aiError}</p>}

             <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
                <div className="md:col-span-1">
                    <label className="block text-sm font-medium">Score (out of {question.points || 0})</label>
                    <input 
                        type="number"
                        value={grade?.score ?? ''}
                        onChange={(e) => onGradeChange({ score: parseInt(e.target.value) || 0, feedback: grade?.feedback })}
                        max={question.points || 0}
                        min={0}
                        className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 shadow-sm"
                    />
                </div>
                <div className="md:col-span-4">
                     <label className="block text-sm font-medium">Feedback</label>
                     <textarea 
                        value={grade?.feedback ?? ''}
                        onChange={(e) => onGradeChange({ score: grade?.score ?? 0, feedback: e.target.value })}
                        rows={3}
                        className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 shadow-sm"
                     />
                </div>
             </div>
        </div>
    )
}


const SubmissionDetail: React.FC<{
  submission: Submission,
  exam: Exam,
  onSave: (grades: Record<string, { score: number, feedback?: string }>, finalScore: number) => void
}> = ({ submission, exam, onSave }) => {
    const [grades, setGrades] = useState(submission.grades || {});
    
    const questionsById = useMemo(() => 
        exam.questions.reduce((acc, q) => {
            acc[q.id] = q;
            return acc;
        }, {} as Record<string, Question>), 
    [exam.questions]);

    const handleGradeChange = (questionId: string, grade: { score: number, feedback?: string }) => {
        setGrades(prev => ({ ...prev, [questionId]: grade }));
    };

    const calculateFinalScore = () => {
        // Fix: Add a type assertion to `grade` to resolve the error "Property 'score' does not exist on type 'unknown'".
        // TypeScript can sometimes infer the type of `Object.values` too broadly.
        return Object.values(grades).reduce((total, grade) => total + ((grade as { score: number }).score || 0), 0);
    }
    
    const totalPossibleScore = exam.questions.reduce((sum, q) => sum + (q.points || 0), 0);

    const handleSave = () => {
        onSave(grades, calculateFinalScore());
        alert("Grades saved!");
    }

    return (
        <div className="bg-white dark:bg-slate-800 rounded-lg p-6">
            <div className="flex justify-between items-center mb-4 pb-4 border-b dark:border-slate-700">
                <div>
                    <h3 className="text-xl font-bold">Submission by {submission.studentName}</h3>
                    <p className="text-sm text-slate-500">Submitted on: {new Date(submission.submittedAt).toLocaleString()}</p>
                </div>
                <div className="text-right">
                    <p className="text-2xl font-bold">{calculateFinalScore()} / {totalPossibleScore}</p>
                    <p className="text-sm text-slate-500">Final Score</p>
                </div>
            </div>
            
            <div className="space-y-6 max-h-[60vh] overflow-y-auto pr-2">
                {exam.questions.map((q, index) => {
                    const answer = submission.answers[q.id];
                    const grade = grades[q.id];
                    let correctnessUI: React.ReactNode = null;
                    if (q.type !== QuestionType.Essay) {
                        correctnessUI = grade?.score > 0
                            ? <span className="text-xs font-bold text-green-600 bg-green-100 dark:bg-green-900 dark:text-green-300 px-2 py-1 rounded-full">CORRECT</span>
                            : <span className="text-xs font-bold text-red-600 bg-red-100 dark:bg-red-900 dark:text-red-300 px-2 py-1 rounded-full">INCORRECT</span>
                    }

                    return (
                        <div key={q.id}>
                            <div className="flex justify-between items-start">
                                <h4 className="font-semibold text-lg">{index + 1}. {q.text} ({q.points || 0} pts)</h4>
                                {correctnessUI}
                            </div>
                            {q.type === QuestionType.MCQ && <p className="mt-2">Answer: <span className="font-mono bg-slate-100 dark:bg-slate-700 p-1 rounded">{answer}</span></p>}
                             {q.type === QuestionType.FillInTheBlank && <p className="mt-2">Answer: <span className="font-mono bg-slate-100 dark:bg-slate-700 p-1 rounded">{(answer as string[] || []).join(', ')}</span></p>}
                            {q.type === QuestionType.Essay && (
                                <EssayGradingCard 
                                    question={q}
                                    answer={answer}
                                    grade={grade}
                                    onGradeChange={(newGrade) => handleGradeChange(q.id, newGrade)}
                                />
                            )}
                        </div>
                    )
                })}
            </div>

             <div className="flex justify-end mt-6 pt-6 border-t dark:border-slate-700">
                <button onClick={handleSave} className="px-6 py-2 bg-green-600 text-white font-semibold rounded-lg hover:bg-green-700 transition">
                    Save Grades
                </button>
            </div>
        </div>
    )
}

const GradingView: React.FC<GradingViewProps> = ({ exam, submissions, onBack, onSaveGrade }) => {
    const [selectedSubmission, setSelectedSubmission] = useState<Submission | null>(submissions.length > 0 ? submissions[0] : null);
    
    return (
        <div className="container mx-auto p-4 sm:p-6 lg:p-8">
            <header className="flex items-center mb-8">
                <button onClick={onBack} className="mr-4 p-2 rounded-full hover:bg-slate-200 dark:hover:bg-slate-700 transition">
                     <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 19l-7-7m0 0l7-7m-7 7h18" /></svg>
                </button>
                <div>
                    <h1 className="text-4xl font-extrabold text-slate-900 dark:text-white">Grade Submissions</h1>
                    <p className="text-slate-600 dark:text-slate-400 mt-1">Reviewing submissions for: {exam.title}</p>
                </div>
            </header>

            <div className="flex flex-col md:flex-row gap-8">
                <aside className="w-full md:w-1/3 lg:w-1/4 bg-white dark:bg-slate-800 p-4 rounded-xl shadow-lg">
                    <h2 className="text-lg font-bold mb-4">Students ({submissions.length})</h2>
                    <ul className="space-y-2 max-h-[70vh] overflow-y-auto">
                        {submissions.map(sub => {
                          return (
                             <li key={sub.id}>
                                <button 
                                    onClick={() => setSelectedSubmission(sub)}
                                    className={`w-full text-left p-3 rounded-lg transition ${selectedSubmission?.id === sub.id ? 'bg-indigo-100 dark:bg-indigo-900 font-bold' : 'hover:bg-slate-100 dark:hover:bg-slate-700'}`}
                                >
                                    <div className="flex justify-between items-center">
                                      <span>{sub.studentName}</span>
                                    </div>
                                    <span className="block text-xs text-slate-500">Score: {sub.finalScore ?? 'Not Graded'}</span>
                                </button>
                             </li>
                          )
                        })}
                    </ul>
                </aside>
                <main className="flex-grow">
                     {selectedSubmission ? (
                        <SubmissionDetail 
                            submission={selectedSubmission} 
                            exam={exam}
                            onSave={(grades, finalScore) => onSaveGrade(selectedSubmission.id, grades, finalScore)}
                        />
                     ) : (
                        <div className="bg-white dark:bg-slate-800 rounded-lg p-12 text-center shadow-lg">
                            <h3 className="text-xl font-semibold">No submissions yet.</h3>
                            <p className="text-slate-500 mt-2">When students submit this exam, their submissions will appear here.</p>
                        </div>
                     )}
                </main>
            </div>

        </div>
    );
};

export default GradingView;