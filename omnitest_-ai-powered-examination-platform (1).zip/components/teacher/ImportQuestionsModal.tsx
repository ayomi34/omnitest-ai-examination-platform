import React, { useState, useCallback } from 'react';
import * as XLSX from 'xlsx';
import { Question, QuestionType } from '../../types';
import Modal from '../shared/Modal';
import Spinner from '../shared/Spinner';

interface ImportQuestionsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAppend: (questions: Omit<Question, 'id'>[]) => void;
}

const ImportQuestionsModal: React.FC<ImportQuestionsModalProps> = ({ isOpen, onClose, onAppend }) => {
  const [file, setFile] = useState<File | null>(null);
  const [parsedQuestions, setParsedQuestions] = useState<Omit<Question, 'id'>[]>([]);
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setFile(e.target.files[0]);
      setError('');
      setParsedQuestions([]);
    }
  };

  const processFile = useCallback(() => {
    if (!file) {
      setError('Please select a file first.');
      return;
    }
    setIsLoading(true);
    setError('');
    setParsedQuestions([]);

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = e.target?.result;
        const workbook = XLSX.read(data, { type: 'binary' });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        const json = XLSX.utils.sheet_to_json<any>(worksheet);

        const mappedQuestions = json.map((row, index) => {
          if (!row['Question'] || !row['Type'] || !row['Marks']) {
            throw new Error(`Row ${index + 2} is missing required fields (Question, Type, Marks).`);
          }
          const typeStr = String(row['Type']).trim().toLowerCase();
          const question: Omit<Question, 'id'> = {
            text: String(row['Question']),
            points: Number(row['Marks']),
            type: typeStr as QuestionType,
          };

          if (typeStr === 'mcq') {
            question.options = ['A', 'B', 'C', 'D']
              .map(char => row[`Option ${char}`])
              .filter(Boolean)
              .map(String);
            
            if (question.options.length < 2) throw new Error(`Row ${index + 2}: MCQs must have at least 2 options.`);
            
            const correctOptChar = String(row['Correct Option']).trim().toUpperCase();
            const correctOptValue = row[`Option ${correctOptChar}`];
            if (!correctOptValue) throw new Error(`Row ${index + 2}: Correct Option '${correctOptChar}' does not correspond to a valid option.`);
            
            question.correctAnswer = String(correctOptValue);
          } else if (typeStr === 'essay') {
            question.rubric = row['Rubric'] ? String(row['Rubric']) : undefined;
          } else if (typeStr === 'fill-in-the-blank') {
             if (!row['Correct Answers']) {
                throw new Error(`Row ${index + 2}: 'fill-in-the-blank' questions require a 'Correct Answers' column.`);
            }
            question.correctAnswer = String(row['Correct Answers']).split(';').map(s => s.trim());
          } else {
             throw new Error(`Row ${index + 2}: Unsupported question type '${typeStr}'.`);
          }
          return question;
        });

        setParsedQuestions(mappedQuestions);
      } catch (err: any) {
        setError(err.message || 'Failed to process file. Ensure it follows the required format.');
        console.error(err);
      } finally {
        setIsLoading(false);
      }
    };
    reader.onerror = () => {
      setError('Failed to read the file.');
      setIsLoading(false);
    };
    reader.readAsBinaryString(file);
  }, [file]);
  
  const handleAddQuestions = () => {
    onAppend(parsedQuestions);
    onClose();
  }

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Import Questions from File">
      <div className="space-y-4">
        <div className="p-4 bg-slate-100 dark:bg-slate-700 rounded-lg text-sm">
          <h4 className="font-bold mb-2">File Format Instructions</h4>
          <p>Your file can have the following columns: <strong>Question, Type, Marks, Option A, Option B, C, D, Correct Option, Correct Answers, Rubric</strong>.</p>
          <ul className="list-disc list-inside mt-2 space-y-1">
            <li><strong>Type:</strong> 'mcq', 'essay', or 'fill-in-the-blank'.</li>
            <li><strong>Correct Option:</strong> For MCQs, use 'A', 'B', 'C', or 'D'.</li>
            <li>For 'fill-in-the-blank', provide answers in the <strong>Correct Answers</strong> column, separated by semicolons (e.g., answer1;answer2).</li>
            <li>Other columns can be empty if not applicable (e.g., options for an essay).</li>
          </ul>
        </div>
        
        <div className="flex items-center gap-4">
          <input
            type="file"
            accept=".csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel"
            onChange={handleFileChange}
            className="block w-full text-sm text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100"
          />
          <button onClick={processFile} disabled={!file || isLoading} className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 disabled:bg-indigo-400">
            {isLoading ? 'Processing...' : 'Process File'}
          </button>
        </div>

        {isLoading && <div className="text-center p-8"><Spinner text="Parsing file..." /></div>}
        {error && <p className="text-red-500 bg-red-100 dark:bg-red-900 p-3 rounded-lg">{error}</p>}
        
        {parsedQuestions.length > 0 && (
          <div className="mt-4">
            <h4 className="font-bold mb-2">Preview ({parsedQuestions.length} questions found)</h4>
            <div className="max-h-64 overflow-y-auto border dark:border-slate-600 rounded-lg p-2 space-y-2 bg-slate-50 dark:bg-slate-900">
              {parsedQuestions.map((q, i) => (
                <div key={i} className="p-2 border-b dark:border-slate-700 text-sm">
                  <p><strong>{i+1}. {q.text}</strong> ({q.type}, {q.points} pts)</p>
                  {q.type === 'mcq' && <p className="text-green-600 dark:text-green-400">Correct: {q.correctAnswer}</p>}
                </div>
              ))}
            </div>
          </div>
        )}
        
        <div className="flex justify-end gap-4 pt-6 border-t border-slate-200 dark:border-slate-700">
          <button type="button" onClick={onClose} className="px-6 py-2 bg-slate-200 dark:bg-slate-600 rounded-lg hover:bg-slate-300 dark:hover:bg-slate-500 transition">Cancel</button>
          <button type="button" onClick={handleAddQuestions} disabled={parsedQuestions.length === 0} className="px-6 py-2 bg-green-600 text-white font-semibold rounded-lg hover:bg-green-700 transition disabled:bg-green-400">
            Add {parsedQuestions.length} Questions
          </button>
        </div>
      </div>
    </Modal>
  );
};

export default ImportQuestionsModal;