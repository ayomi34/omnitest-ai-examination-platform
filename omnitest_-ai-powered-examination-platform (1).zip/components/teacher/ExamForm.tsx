import React, { useState, useEffect } from 'react';
import { Exam, Question, QuestionType } from '../../types';
import Modal from '../shared/Modal';
import QuestionEditor from './QuestionEditor';
import ImportQuestionsModal from './ImportQuestionsModal';
import GenerateQuestionsModal from './GenerateQuestionsModal';
import { v4 as uuidv4 } from 'uuid';

interface ExamFormProps {
  existingExam: Exam | null;
  onSave: (exam: Exam) => void;
  onCancel: () => void;
}

const ExamForm: React.FC<ExamFormProps> = ({ existingExam, onSave, onCancel }) => {
  const [exam, setExam] = useState<Omit<Exam, 'id' | 'teacherId'> & { id?: string, teacherId?: string }>({
    title: '',
    subject: '',
    duration: 60,
    questions: [],
  });
  
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [isGenerateModalOpen, setIsGenerateModalOpen] = useState(false);

  useEffect(() => {
    if (existingExam) {
      setExam(existingExam);
    }
  }, [existingExam]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setExam(prev => ({ ...prev, [name]: name === 'duration' ? parseInt(value, 10) : value }));
  };
  
  const handleAppendQuestions = (newQuestions: Omit<Question, 'id'>[]) => {
      const questionsWithIds = newQuestions.map(q => ({ ...q, id: uuidv4() }));
      setExam(prev => ({
          ...prev,
          questions: [...prev.questions, ...questionsWithIds],
      }));
  };

  const handleSaveQuestion = (question: Question) => {
    const questionExists = exam.questions.some(q => q.id === question.id);
    if (questionExists) {
      setExam(prev => ({
        ...prev,
        questions: prev.questions.map(q => q.id === question.id ? question : q),
      }));
    } else {
      setExam(prev => ({
        ...prev,
        questions: [...prev.questions, question],
      }));
    }
  };

  const handleAddQuestion = () => {
    const newQuestion: Question = {
      id: uuidv4(),
      text: '',
      type: QuestionType.MCQ,
      options: ['', ''],
      correctAnswer: '',
      points: 1,
    };
    setExam(prev => ({
      ...prev,
      questions: [...prev.questions, newQuestion],
    }));
  };

  const handleDeleteQuestion = (questionId: string) => {
    if(window.confirm('Are you sure you want to delete this question?')) {
        setExam(prev => ({
            ...prev,
            questions: prev.questions.filter(q => q.id !== questionId),
        }));
    }
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(exam as Exam);
  };

  return (
    <>
      <Modal isOpen={true} onClose={onCancel} title={existingExam ? 'Edit Exam' : 'Create New Exam'}>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="md:col-span-1">
                  <label htmlFor="title" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Title</label>
                  <input type="text" name="title" id="title" value={exam.title} onChange={handleInputChange} required className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"/>
              </div>
              <div className="md:col-span-1">
                  <label htmlFor="subject" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Subject</label>
                  <input type="text" name="subject" id="subject" value={exam.subject} onChange={handleInputChange} required className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"/>
              </div>
              <div className="md:col-span-1">
                  <label htmlFor="duration" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Duration (Minutes)</label>
                  <input type="number" name="duration" id="duration" value={exam.duration} onChange={handleInputChange} required className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"/>
              </div>
          </div>
          
          <div className="border-t border-slate-200 dark:border-slate-700 pt-6">
              <div className="flex flex-wrap justify-between items-center mb-4 gap-2">
                  <h3 className="text-xl font-bold">Questions</h3>
                  <div className="flex flex-wrap gap-2">
                    <button type="button" onClick={() => setIsImportModalOpen(true)} className="px-3 py-2 text-sm bg-slate-600 text-white rounded-lg hover:bg-slate-700 transition">Import from File</button>
                    <button type="button" onClick={() => setIsGenerateModalOpen(true)} className="px-3 py-2 text-sm bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition">Generate with AI</button>
                    <button type="button" onClick={handleAddQuestion} className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition">
                        + Add Manually
                    </button>
                  </div>
              </div>
              <div className="space-y-4 max-h-[50vh] overflow-y-auto pr-2">
                  {exam.questions.map((q, index) => (
                      <QuestionEditor
                          key={q.id}
                          question={q}
                          onSave={handleSaveQuestion}
                          onDelete={handleDeleteQuestion}
                          index={index}
                      />
                  ))}
                  {exam.questions.length === 0 && (
                    <div className="text-center py-8 text-slate-500 dark:text-slate-400">
                      <p>No questions yet.</p>
                      <p>Add questions manually, import from a file, or generate them with AI.</p>
                    </div>
                  )}
              </div>
          </div>

          <div className="flex justify-end gap-4 pt-6 border-t border-slate-200 dark:border-slate-700">
            <button type="button" onClick={onCancel} className="px-6 py-2 bg-slate-200 dark:bg-slate-600 rounded-lg hover:bg-slate-300 dark:hover:bg-slate-500 transition">
              Cancel
            </button>
            <button type="submit" className="px-6 py-2 bg-green-600 text-white font-semibold rounded-lg hover:bg-green-700 transition">
              Save Exam
            </button>
          </div>
        </form>
      </Modal>

      {isImportModalOpen && (
        <ImportQuestionsModal 
            isOpen={isImportModalOpen}
            onClose={() => setIsImportModalOpen(false)}
            onAppend={handleAppendQuestions}
        />
      )}
      {isGenerateModalOpen && (
        <GenerateQuestionsModal
            isOpen={isGenerateModalOpen}
            onClose={() => setIsGenerateModalOpen(false)}
            onAppend={handleAppendQuestions}
        />
      )}
    </>
  );
};

export default ExamForm;