import React, { useState, useCallback } from 'react';
import * as XLSX from 'xlsx';
import { User } from '../../types';
import Modal from './Modal';
import Spinner from './Spinner';

interface ImportStudentsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onImport: (usersData: { fullName: string }[]) => (User & { plainPassword?: string })[];
}

const ImportStudentsModal: React.FC<ImportStudentsModalProps> = ({ isOpen, onClose, onImport }) => {
  const [file, setFile] = useState<File | null>(null);
  const [parsedData, setParsedData] = useState<{ fullName: string }[]>([]);
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [importedUsers, setImportedUsers] = useState<(User & { plainPassword?: string })[]>([]);

  const resetState = useCallback(() => {
    setFile(null);
    setParsedData([]);
    setError('');
    setIsLoading(false);
    setIsSuccess(false);
    setImportedUsers([]);
  }, []);

  const handleClose = () => {
    resetState();
    onClose();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files?.[0]) {
      setFile(e.target.files[0]);
      setError('');
      setParsedData([]);
      setIsSuccess(false);
    }
  };

  const processFile = useCallback(() => {
    if (!file) return;
    setIsLoading(true);
    setError('');
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = e.target?.result;
        const workbook = XLSX.read(data, { type: 'binary' });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        const json = XLSX.utils.sheet_to_json<any>(worksheet, { header: 1, blankrows: false });
        
        if (json.length < 2) throw new Error("File is empty or contains only a header.");

        const header = (json[0] as string[]).map(h => String(h || '').trim().toLowerCase());
        const nameIndex = header.indexOf('fullname');
        if (nameIndex === -1) throw new Error("File must contain a 'FullName' column header.");

        const names = json.slice(1)
          .map((row: any[]) => ({ fullName: String(row[nameIndex] || '').trim() }))
          .filter(student => student.fullName);

        if (names.length === 0) throw new Error("No student names found in the 'FullName' column.");
        
        setParsedData(names);
      } catch (err: any) {
        setError(err.message || 'Failed to parse file. Please check the format and try again.');
      } finally {
        setIsLoading(false);
      }
    };
    reader.onerror = () => {
        setIsLoading(false);
        setError('Could not read the selected file.');
    };
    reader.readAsBinaryString(file);
  }, [file]);

  const handleConfirmImport = () => {
    setIsLoading(true);
    // Simulate async operation
    setTimeout(() => {
        const newUsers = onImport(parsedData);
        setImportedUsers(newUsers);
        setIsSuccess(true);
        setIsLoading(false);
    }, 500);
  };
  
  const handleDownloadCredentials = () => {
    const dataToExport = importedUsers.map(user => ({
        'FullName': user.fullName,
        'Username': user.username,
        'Password': user.plainPassword,
    }));
    const worksheet = XLSX.utils.json_to_sheet(dataToExport);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Student Credentials');
    XLSX.writeFile(workbook, 'student-credentials.xlsx');
  };

  const renderContent = () => {
    if (isLoading) {
      return <div className="text-center p-8"><Spinner text="Processing..." /></div>;
    }
    
    if (isSuccess) {
      return (
        <div className="text-center p-6 bg-green-50 dark:bg-green-900 rounded-lg">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 text-green-500 mx-auto" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
            <h3 className="mt-4 text-xl font-bold text-green-800 dark:text-green-300">Success!</h3>
            <p className="mt-2 text-slate-600 dark:text-slate-300">
                Successfully created {importedUsers.length} new student accounts.
            </p>
            <p className="mt-2 text-sm text-slate-500 dark:text-slate-400">
                Download the file below to share the login details with your students.
            </p>
            <button
                onClick={handleDownloadCredentials}
                className="mt-6 px-6 py-2 bg-green-600 text-white font-semibold rounded-lg hover:bg-green-700 transition"
            >
                Download Login Details
            </button>
        </div>
      );
    }
    
    return (
      <>
        <div className="p-4 bg-slate-100 dark:bg-slate-700 rounded-lg text-sm">
            <h4 className="font-bold mb-2">Instructions</h4>
            <p>Upload a CSV or Excel file with a column header named <strong>FullName</strong> containing the list of your students.</p>
        </div>

        <div className="flex flex-col sm:flex-row items-center gap-4 mt-4">
            <input
                type="file"
                accept=".csv, .xlsx, .xls"
                onChange={handleFileChange}
                className="block w-full text-sm text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-indigo-50 dark:file:bg-indigo-900 file:text-indigo-700 dark:file:text-indigo-300 hover:file:bg-indigo-100 dark:hover:file:bg-indigo-800"
            />
            <button onClick={processFile} disabled={!file} className="w-full sm:w-auto px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 disabled:bg-indigo-400 flex-shrink-0">
                Preview File
            </button>
        </div>
        
        {error && <p className="mt-4 text-red-600 bg-red-100 dark:bg-red-900 dark:text-red-300 p-3 rounded-lg text-sm">{error}</p>}
        
        {parsedData.length > 0 && (
          <div className="mt-4">
            <h4 className="font-bold mb-2 text-slate-800 dark:text-slate-200">Preview ({parsedData.length} students found)</h4>
            <div className="max-h-48 overflow-y-auto border dark:border-slate-600 rounded-lg p-2 space-y-1 bg-slate-50 dark:bg-slate-900">
              {parsedData.map((student, i) => (
                <p key={i} className="text-sm text-slate-700 dark:text-slate-300 p-1 border-b border-slate-200 dark:border-slate-700 last:border-0">{student.fullName}</p>
              ))}
            </div>
          </div>
        )}
      </>
    );
  };
  
  return (
    <Modal isOpen={isOpen} onClose={handleClose} title="Import Students from File">
        <div className="space-y-6">
            {renderContent()}
            {!isSuccess && (
                 <div className="flex justify-end gap-4 pt-6 mt-6 border-t border-slate-200 dark:border-slate-700">
                    <button type="button" onClick={handleClose} className="px-6 py-2 bg-slate-200 dark:bg-slate-600 text-slate-800 dark:text-slate-200 rounded-lg hover:bg-slate-300 dark:hover:bg-slate-500 transition">Cancel</button>
                    <button type="button" onClick={handleConfirmImport} disabled={parsedData.length === 0 || isLoading} className="px-6 py-2 bg-green-600 text-white font-semibold rounded-lg hover:bg-green-700 transition disabled:bg-green-400 disabled:cursor-not-allowed">
                        Confirm & Add {parsedData.length > 0 ? parsedData.length : ''} Students
                    </button>
                </div>
            )}
            {isSuccess && (
                 <div className="flex justify-end gap-4 pt-6 mt-6 border-t border-slate-200 dark:border-slate-700">
                    <button type="button" onClick={handleClose} className="px-6 py-2 bg-indigo-600 text-white font-semibold rounded-lg hover:bg-indigo-700 transition">
                        Close
                    </button>
                </div>
            )}
        </div>
    </Modal>
  );
};

export default ImportStudentsModal;
