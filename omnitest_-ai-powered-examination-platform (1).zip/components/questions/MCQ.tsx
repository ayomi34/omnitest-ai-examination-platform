import React from 'react';
import { Question } from '../../types';

interface MCQProps {
  question: Question;
  answer: string | null;
  onAnswer: (answer: string) => void;
}

const MCQ: React.FC<MCQProps> = ({ question, answer, onAnswer }) => {
  return (
    <div className="space-y-4">
      {question.options?.map((option, index) => (
        <label
          key={index}
          className={`flex items-center p-4 rounded-lg border-2 cursor-pointer transition-all duration-200 ${
            answer === option
              ? 'bg-indigo-100 dark:bg-indigo-900 border-indigo-500 shadow-md'
              : 'bg-slate-50 dark:bg-slate-700 border-slate-200 dark:border-slate-600 hover:border-indigo-400'
          }`}
        >
          <input
            type="radio"
            name={question.id}
            value={option}
            checked={answer === option}
            onChange={() => onAnswer(option)}
            className="h-5 w-5 text-indigo-600 focus:ring-indigo-500 border-gray-300"
          />
          <span className="ml-4 text-lg text-slate-800 dark:text-slate-200">{option}</span>
        </label>
      ))}
    </div>
  );
};

export default MCQ;
