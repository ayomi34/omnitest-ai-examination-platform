import React, { useState } from 'react';
import { Question } from '../../types';

interface EssayProps {
  question: Question;
  answer: string | null;
  onAnswer: (answer: string) => void;
}

const Essay: React.FC<EssayProps> = ({ question, answer, onAnswer }) => {
  const [showAlert, setShowAlert] = useState(false);
  const text = answer || '';
  const wordCount = text.trim() ? text.trim().split(/\s+/).length : 0;

  const handlePaste = (e: React.ClipboardEvent) => {
    e.preventDefault();
    setShowAlert(true);
    setTimeout(() => setShowAlert(false), 3000);
  };

  return (
    <div>
      {showAlert && (
        <div className="mb-4 p-3 bg-red-100 border border-red-400 text-red-700 rounded-lg animate-pulse">
          Pasting content is not allowed.
        </div>
      )}
      <textarea
        value={text}
        onChange={(e) => onAnswer(e.target.value)}
        onPaste={handlePaste}
        placeholder="Type your essay here..."
        className="w-full h-64 p-4 border-2 border-slate-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition bg-white dark:bg-slate-900 text-lg"
      />
      <div className="text-right mt-2 text-sm text-slate-500 dark:text-slate-400">
        Word Count: {wordCount}
      </div>
      {question.rubric && (
         <div className="mt-4 p-4 bg-slate-100 dark:bg-slate-700 rounded-lg">
            <h4 className="font-semibold text-md mb-2">Grading Rubric</h4>
            <p className="text-sm text-slate-600 dark:text-slate-300 whitespace-pre-wrap">{question.rubric}</p>
         </div>
      )}
    </div>
  );
};

export default Essay;
