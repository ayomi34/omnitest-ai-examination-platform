import React from 'react';
import { Question } from '../../types';

interface FillInTheBlankProps {
  question: Question;
  answer: string[] | null;
  onAnswer: (answer: string[]) => void;
}

const FillInTheBlank: React.FC<FillInTheBlankProps> = ({ question, answer, onAnswer }) => {
  const parts = question.text.split('___');
  const answers = answer || Array(parts.length - 1).fill('');

  const handleInputChange = (index: number, value: string) => {
    const newAnswers = [...answers];
    newAnswers[index] = value;
    onAnswer(newAnswers);
  };

  return (
    <div className="text-lg space-x-2 flex items-center flex-wrap">
      {parts.map((part, index) => (
        <React.Fragment key={index}>
          <span className="leading-loose">{part}</span>
          {index < parts.length - 1 && (
            <input
              type="text"
              value={answers[index] || ''}
              onChange={(e) => handleInputChange(index, e.target.value)}
              className="inline-block w-40 px-2 py-1 border-b-2 border-slate-400 focus:border-indigo-500 bg-transparent outline-none transition"
              autoCapitalize="off"
            />
          )}
        </React.Fragment>
      ))}
    </div>
  );
};

export default FillInTheBlank;
