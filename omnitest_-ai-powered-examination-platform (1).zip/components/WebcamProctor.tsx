import React, { useRef, useEffect, useState } from 'react';
import * as faceapi from 'face-api.js';

const MODEL_URL = 'https://cdn.jsdelivr.net/npm/face-api.js@0.22.2/weights';

interface WebcamProctorProps {
  onInfraction: (message: string) => void;
}

const WebcamProctor: React.FC<WebcamProctorProps> = ({ onInfraction }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [error, setError] = useState<string | null>(null);
  const [isCameraOn, setIsCameraOn] = useState(false);
  const [modelsLoaded, setModelsLoaded] = useState(false);
  const [lastInfractionType, setLastInfractionType] = useState<'none' | 'no_face' | 'multi_face'>('none');
  
  const detectionIntervalRef = useRef<number | undefined>(undefined);
  const onInfractionRef = useRef(onInfraction);
  onInfractionRef.current = onInfraction;

  useEffect(() => {
    const loadModels = async () => {
      try {
        await faceapi.nets.tinyFaceDetector.loadFromUri(MODEL_URL);
        setModelsLoaded(true);
      } catch (e) {
        console.error("Failed to load face detection models:", e);
        setError("AI models failed to load. Proctoring limited.");
      }
    };
    loadModels();
  }, []);

  useEffect(() => {
    let stream: MediaStream | null = null;
    
    const startCamera = async () => {
      try {
        stream = await navigator.mediaDevices.getUserMedia({ video: true });
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          setIsCameraOn(true);
          setError(null);
        }
      } catch (err) {
        console.error("Error accessing webcam:", err);
        setError("Webcam access denied. Proctoring is disabled.");
        setIsCameraOn(false);
      }
    };

    startCamera();

    return () => {
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  useEffect(() => {
    if (isCameraOn && modelsLoaded && videoRef.current) {
        // Give a grace period for the camera to initialize and user to settle
        const gracePeriod = setTimeout(() => {
            detectionIntervalRef.current = window.setInterval(async () => {
                if (videoRef.current && !videoRef.current.paused) {
                    const detections = await faceapi.detectAllFaces(videoRef.current, new faceapi.TinyFaceDetectorOptions());
                    
                    if (detections.length === 0) {
                        if (lastInfractionType !== 'no_face') {
                            onInfractionRef.current("No face detected. Please remain in front of the camera.");
                            setLastInfractionType('no_face');
                        }
                    } else if (detections.length > 1) {
                         if (lastInfractionType !== 'multi_face') {
                            onInfractionRef.current("Multiple people were detected.");
                            setLastInfractionType('multi_face');
                        }
                    } else { // detections.length === 1, which is correct
                        setLastInfractionType('none');
                    }
                }
            }, 5000); // Check every 5 seconds
        }, 5000); // 5 second initial grace period

        return () => {
            clearTimeout(gracePeriod);
            clearInterval(detectionIntervalRef.current);
        }
    }
  }, [isCameraOn, modelsLoaded, lastInfractionType]);


  return (
    <div className="mt-6 p-3 bg-slate-100 dark:bg-slate-700 rounded-lg">
      <h3 className="text-sm font-semibold mb-2 text-slate-800 dark:text-slate-200">Webcam Proctoring</h3>
      <div className="aspect-video bg-black rounded overflow-hidden relative">
        <video ref={videoRef} autoPlay playsInline muted className="w-full h-full object-cover"></video>
        {!isCameraOn && (
            <div className="absolute inset-0 flex flex-col items-center justify-center text-white bg-black bg-opacity-50">
                <svg className="w-8 h-8 mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z"></path></svg>
                <span className="text-xs text-center">{error || (modelsLoaded ? "Starting camera..." : "Loading AI models...")}</span>
            </div>
        )}
        {isCameraOn && 
          <div className="absolute top-2 right-2 flex items-center space-x-1 bg-red-600 text-white text-xs font-bold px-2 py-1 rounded">
            <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
            <span>REC</span>
          </div>
        }
      </div>
    </div>
  );
};

export default WebcamProctor;