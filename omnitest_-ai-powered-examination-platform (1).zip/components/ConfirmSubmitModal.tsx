import React from 'react';

interface ConfirmSubmitModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  answeredQuestions: number;
  totalQuestions: number;
  timeLeft: number;
}

const ConfirmSubmitModal: React.FC<ConfirmSubmitModalProps> = ({
  isOpen,
  onClose,
  onConfirm,
  answeredQuestions,
  totalQuestions,
  timeLeft,
}) => {
  if (!isOpen) return null;

  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50">
      <div className="bg-white dark:bg-slate-800 rounded-lg shadow-xl p-8 max-w-md w-full transform transition-all animate-fade-in-up">
        <h2 className="text-2xl font-bold text-slate-900 dark:text-white mb-4">Confirm Submission</h2>
        <div className="space-y-4 text-slate-700 dark:text-slate-300 mb-6">
            <p>You are about to submit your exam. Please review the details below:</p>
            <ul className="list-disc list-inside space-y-2 bg-slate-100 dark:bg-slate-700 p-4 rounded-lg">
                <li><strong>Answered:</strong> {answeredQuestions} of {totalQuestions} questions</li>
                <li><strong>Time Remaining:</strong> {String(minutes).padStart(2, '0')}:{String(seconds).padStart(2, '0')}</li>
            </ul>
            <p className="font-semibold text-amber-600 dark:text-amber-400">This action cannot be undone. Are you sure you want to proceed?</p>
        </div>
        <div className="flex justify-end gap-4 mt-8">
            <button
                onClick={onClose}
                className="px-6 py-2 bg-slate-300 dark:bg-slate-600 rounded-lg hover:bg-slate-400 dark:hover:bg-slate-500 transition"
            >
                Cancel
            </button>
            <button
                onClick={onConfirm}
                className="px-6 py-2 bg-green-600 text-white font-semibold rounded-lg hover:bg-green-700 transition"
            >
                Confirm Submit
            </button>
        </div>
      </div>
    </div>
  );
};

export default ConfirmSubmitModal;