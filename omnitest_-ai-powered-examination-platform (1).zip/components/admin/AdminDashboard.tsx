import React, { useState } from 'react';
import { User, Exam, Submission, Role } from '../../types';
import Modal from '../shared/Modal';
import UserForm from './UserForm';
import ImportStudentsModal from '../shared/ImportStudentsModal';

interface AdminDashboardProps {
  admin: User;
  users: User[];
  exams: Exam[];
  submissions: Submission[];
  onLogout: () => void;
  onAddUser: (user: Omit<User, 'id'>) => void;
  onUpdateUser: (user: User) => void;
  onDeleteUser: (userId: string) => void;
  onAddUsersBatch: (usersData: { fullName: string }[]) => (User & { plainPassword?: string })[];
}

const StatCard: React.FC<{ title: string; value: number | string, icon: React.ReactNode }> = ({ title, value, icon }) => (
    <div className="bg-white dark:bg-slate-800 p-6 rounded-xl shadow-lg flex items-center space-x-4">
        <div className="bg-indigo-100 dark:bg-indigo-900 p-3 rounded-full">
            {icon}
        </div>
        <div>
            <p className="text-sm text-slate-500 dark:text-slate-400">{title}</p>
            <p className="text-2xl font-bold text-slate-900 dark:text-white">{value}</p>
        </div>
    </div>
);

const AdminDashboard: React.FC<AdminDashboardProps> = ({ admin, users, exams, submissions, onLogout, onAddUser, onUpdateUser, onDeleteUser, onAddUsersBatch }) => {
    const totalStudents = users.filter(u => u.role === Role.Student).length;
    const totalTeachers = users.filter(u => u.role === Role.Teacher).length;
    
    const [isUserModalOpen, setIsUserModalOpen] = useState(false);
    const [editingUser, setEditingUser] = useState<User | null>(null);
    const [isImportModalOpen, setIsImportModalOpen] = useState(false);

    const handleAddNewUser = () => {
        setEditingUser(null);
        setIsUserModalOpen(true);
    };

    const handleEditUser = (user: User) => {
        setEditingUser(user);
        setIsUserModalOpen(true);
    };

    const handleSaveUser = (user: User | Omit<User, 'id'>) => {
        if ('id' in user) {
            onUpdateUser(user);
        } else {
            onAddUser(user);
        }
        setIsUserModalOpen(false);
    };
    
    const handleDeleteUserConfirm = (userId: string) => {
        if(window.confirm('Are you sure you want to delete this user? This action cannot be undone.')) {
            onDeleteUser(userId);
        }
    }

    return (
        <div className="min-h-screen bg-slate-100 dark:bg-slate-900 text-slate-800 dark:text-slate-200">
            <div className="container mx-auto p-4 sm:p-6 lg:p-8">
                <header className="flex justify-between items-center mb-8">
                    <div>
                        <h1 className="text-4xl font-extrabold text-slate-900 dark:text-white">Admin Dashboard</h1>
                        <p className="text-slate-600 dark:text-slate-400 mt-1">Platform Overview & Management</p>
                    </div>
                    <div className="flex items-center gap-4">
                        <button
                            onClick={() => handleEditUser(admin)}
                            className="p-2 rounded-full hover:bg-slate-200 dark:hover:bg-slate-700 transition"
                            title="Edit Profile"
                        >
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg>
                        </button>
                        <button
                            onClick={onLogout}
                            className="px-4 py-2 bg-red-600 text-white font-semibold rounded-lg hover:bg-red-700 transition-colors shadow-md"
                        >
                            Logout
                        </button>
                    </div>
                </header>
                
                <main>
                    {/* Stats Grid */}
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                        <StatCard title="Total Students" value={totalStudents} icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-indigo-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M12 14a4 4 0 1 0 0-8 4 4 0 0 0 0 8z" /><path d="M16 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" /></svg>} />
                        <StatCard title="Total Teachers" value={totalTeachers} icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-indigo-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg>} />
                        <StatCard title="Total Exams" value={exams.length} icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-indigo-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01" /></svg>} />
                        <StatCard title="Total Submissions" value={submissions.length} icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-indigo-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>} />
                    </div>

                    <div className="bg-white dark:bg-slate-800 p-6 rounded-xl shadow-lg">
                        <div className="flex justify-between items-center mb-4 flex-wrap gap-2">
                            <h3 className="text-xl font-bold">Manage Users</h3>
                            <div className="flex items-center gap-2 flex-wrap">
                                <button onClick={() => setIsImportModalOpen(true)} className="px-4 py-2 bg-green-600 text-white font-semibold rounded-lg hover:bg-green-700 transition-colors shadow-md">
                                    Import Students
                                </button>
                                <button onClick={handleAddNewUser} className="px-4 py-2 bg-indigo-600 text-white font-semibold rounded-lg hover:bg-indigo-700 transition-colors shadow-md">
                                    + Add New User
                                </button>
                            </div>
                        </div>
                        <div className="overflow-y-auto max-h-96">
                            <table className="w-full text-left">
                                <thead className="sticky top-0 bg-slate-50 dark:bg-slate-700">
                                    <tr>
                                        <th className="p-3">Full Name</th>
                                        <th className="p-3">Username</th>
                                        <th className="p-3">Email</th>
                                        <th className="p-3">Role</th>
                                        <th className="p-3 text-right">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {users.map(user => (
                                        <tr key={user.id} className="border-b dark:border-slate-700">
                                            <td className="p-3">{user.fullName}</td>
                                            <td className="p-3">{user.username}</td>
                                            <td className="p-3">{user.email}</td>
                                            <td className="p-3 capitalize"><span className={`px-2 py-1 text-xs rounded-full ${user.role === Role.Student ? 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300' : user.role === Role.Teacher ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300' : 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-300'}`}>{user.role}</span></td>
                                            <td className="p-3 text-right space-x-2">
                                                <button onClick={() => handleEditUser(user)} className="px-3 py-1 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700">Edit</button>
                                                <button onClick={() => handleDeleteUserConfirm(user.id)} className="px-3 py-1 text-sm font-medium text-white bg-red-600 rounded-md hover:bg-red-700">Delete</button>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </main>
            </div>
            {isUserModalOpen && (
                <UserForm 
                    existingUser={editingUser}
                    onSave={handleSaveUser}
                    onCancel={() => setIsUserModalOpen(false)}
                    isProfileEdit={editingUser?.id === admin.id}
                />
            )}
            {isImportModalOpen && (
                <ImportStudentsModal
                    isOpen={isImportModalOpen}
                    onClose={() => setIsImportModalOpen(false)}
                    onImport={onAddUsersBatch}
                />
            )}
        </div>
    );
};

export default AdminDashboard;