import React, { useState, useEffect } from 'react';
import { User, Role } from '../../types';
import Modal from '../shared/Modal';

interface UserFormProps {
    existingUser: User | null;
    onSave: (user: User | Omit<User, 'id'>) => void;
    onCancel: () => void;
    isProfileEdit?: boolean;
}

const UserForm: React.FC<UserFormProps> = ({ existingUser, onSave, onCancel, isProfileEdit = false }) => {
    const [user, setUser] = useState<Omit<User, 'id'> & { id?: string }>({
        fullName: '',
        username: '',
        email: '',
        password: '',
        role: Role.Student,
    });

    useEffect(() => {
        if (existingUser) {
            setUser(existingUser);
        }
    }, [existingUser]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        setUser({ ...user, [e.target.name]: e.target.value });
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSave(user);
    };

    const modalTitle = isProfileEdit ? 'Edit Profile' : (existingUser ? 'Edit User' : 'Add New User');

    return (
        <Modal isOpen={true} onClose={onCancel} title={modalTitle}>
            <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">Full Name</label>
                        <input type="text" name="fullName" value={user.fullName} onChange={handleChange} required className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 shadow-sm" />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">Username</label>
                        <input type="text" name="username" value={user.username} onChange={handleChange} required className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 shadow-sm" />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">Email</label>
                        <input type="email" name="email" value={user.email || ''} onChange={handleChange} required className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 shadow-sm" />
                    </div>
                    {!isProfileEdit && (
                        <div>
                            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">Role</label>
                            <select name="role" value={user.role} onChange={handleChange} className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 shadow-sm">
                                <option value={Role.Student}>Student</option>
                                <option value={Role.Teacher}>Teacher</option>
                                <option value={Role.Admin}>Admin</option>
                            </select>
                        </div>
                    )}
                     <div className="md:col-span-2">
                        <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">Password</label>
                        <input type="password" name="password" value={user.password || ''} onChange={handleChange} required={!existingUser} placeholder={existingUser ? "Leave blank to keep current password" : ""} className="mt-1 block w-full rounded-md border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 shadow-sm" />
                    </div>
                </div>
                <div className="flex justify-end gap-4 pt-6 border-t border-slate-200 dark:border-slate-700">
                    <button type="button" onClick={onCancel} className="px-6 py-2 bg-slate-200 dark:bg-slate-600 rounded-lg hover:bg-slate-300 dark:hover:bg-slate-500 transition">
                        Cancel
                    </button>
                    <button type="submit" className="px-6 py-2 bg-green-600 text-white font-semibold rounded-lg hover:bg-green-700 transition">
                        Save Changes
                    </button>
                </div>
            </form>
        </Modal>
    );
};

export default UserForm;