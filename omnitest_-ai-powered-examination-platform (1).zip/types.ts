// Fix: Define and export all application types from this file. This file previously contained mock data and a circular import, causing widespread type errors.
export enum Role {
    Student = 'student',
    Teacher = 'teacher',
    Admin = 'admin',
}

export enum QuestionType {
    MCQ = 'mcq',
    Essay = 'essay',
    FillInTheBlank = 'fill-in-the-blank',
}

export interface User {
    id: string;
    username: string;
    fullName: string;
    email: string;
    password?: string;
    role: Role;
}

export interface Question {
    id: string;
    text: string;
    type: QuestionType;
    options?: string[];
    correctAnswer?: string | string[];
    points?: number;
    rubric?: string;
}

export interface Exam {
    id: string;
    title: string;
    subject: string;
    duration: number; // in minutes
    teacherId: string;
    questions: Question[];
}

export interface Submission {
    id: string;
    examId: string;
    studentId: string;
    studentName: string;
    answers: Record<string, any>;
    submittedAt: Date;
    grades: Record<string, { score: number; feedback?: string }>;
    finalScore?: number;
}

export interface ChatMessage {
    sender: 'user' | 'ai';
    text: string;
}