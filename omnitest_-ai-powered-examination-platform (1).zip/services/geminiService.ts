import { GoogleGenAI, Type } from "@google/genai";
import { Question, QuestionType } from '../types';

// IMPORTANT: This key is managed externally and assumed to be available in the environment.
// Do not modify or expose this in the UI.
const getAiClient = () => {
    const apiKey = process.env.API_KEY;
    if (!apiKey) {
        console.warn("API_KEY environment variable not set. AI features will be disabled.");
        return null;
    }
    return new GoogleGenAI({ apiKey });
}

interface AIGradingResult {
  score: number;
  feedback: string;
  isPassing: boolean;
}

/**
 * Grades an essay answer using the Gemini API based on a provided rubric.
 * @param question The essay question object, which includes the rubric.
 * @param answer The student's essay answer.
 * @returns A promise that resolves to an AIGradingResult object.
 */
export const gradeEssayWithAI = async (
  question: Question,
  answer: string
): Promise<AIGradingResult | null> => {
  const ai = getAiClient();
  if (!ai) return null;

  if (!question.rubric) {
    console.error("Cannot grade essay: No rubric provided for the question.");
    return null;
  }

  const prompt = `
    You are an expert teaching assistant. Your task is to grade a student's essay based on a specific question and a provided rubric.
    Provide a score, detailed feedback, and a determination of whether the answer is passing. The maximum score is determined by summing the points in the rubric.

    **Question:**
    ${question.text}

    **Grading Rubric:**
    ${question.rubric}

    **Student's Answer:**
    ${answer}

    Base the "isPassing" field on whether the student achieved at least 50% of the total possible points.
  `;

  try {
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-pro',
        contents: prompt,
        config: {
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    score: {
                        type: Type.NUMBER,
                        description: "The numerical score awarded based on the rubric.",
                    },
                    feedback: {
                        type: Type.STRING,
                        description: "Detailed feedback for the student, explaining the score based on the rubric.",
                    },
                    isPassing: {
                        type: Type.BOOLEAN,
                        description: "True if the score is 50% or higher of the maximum possible points.",
                    },
                },
                required: ['score', 'feedback', 'isPassing'],
            },
        }
    });
    
    const jsonText = response.text.trim();
    const result: AIGradingResult = JSON.parse(jsonText);
    
    return result;

  } catch (error) {
    console.error("Error grading essay with AI:", error);
    return null;
  }
};


export interface QuestionGenerationParams {
    text: string;
    count: number;
    type: QuestionType;
}

/**
 * Generates exam questions from study material using the Gemini API.
 * @param params The parameters for question generation including text, count, and type.
 * @returns A promise that resolves to an array of question objects without IDs.
 */
export const generateQuestionsFromText = async (
    params: QuestionGenerationParams
): Promise<Omit<Question, 'id'>[] | null> => {
    const ai = getAiClient();
    if (!ai) return null;

    const { text, count, type } = params;

    const typeDescription = {
        [QuestionType.MCQ]: "multiple-choice questions with 4 options and one correct answer.",
        [QuestionType.Essay]: "open-ended essay questions that require a detailed explanation, along with a simple grading rubric.",
        [QuestionType.FillInTheBlank]: "sentences with one or more blanks indicated by '___'. Provide the correct words for the blanks in the `correctAnswer` array."
    };

    const prompt = `
        You are an expert educator creating an exam. Based on the following study material, generate exactly ${count} ${typeDescription[type]}.

        Study Material:
        ---
        ${text}
        ---

        Ensure the questions are relevant, clear, and directly derived from the provided text.
        For MCQ, provide 4 distinct options and clearly indicate the correct one in the 'correctAnswer' field.
        For Fill-in-the-blank, the question 'text' field should contain '___' for each blank, and the 'correctAnswer' field must be an array of strings.
        For Essay, provide a simple 'rubric' for grading.
        Provide a reasonable point value for each question. For MCQs and Fill-in-the-blank, it should be 1 point. For essays, it can be higher (5 or 10) based on complexity.
    `;
    
    const mcqSchema = {
        type: Type.OBJECT,
        properties: {
            text: { type: Type.STRING },
            type: { type: Type.STRING, enum: [QuestionType.MCQ] },
            options: { type: Type.ARRAY, items: { type: Type.STRING } },
            correctAnswer: { type: Type.STRING },
            points: { type: Type.NUMBER }
        },
        required: ['text', 'type', 'options', 'correctAnswer', 'points']
    };

    const essaySchema = {
         type: Type.OBJECT,
        properties: {
            text: { type: Type.STRING },
            type: { type: Type.STRING, enum: [QuestionType.Essay] },
            points: { type: Type.NUMBER },
            rubric: { type: Type.STRING }
        },
        required: ['text', 'type', 'points', 'rubric']
    };
    
    const fillInTheBlankSchema = {
        type: Type.OBJECT,
        properties: {
            text: { type: Type.STRING },
            type: { type: Type.STRING, enum: [QuestionType.FillInTheBlank] },
            correctAnswer: { type: Type.ARRAY, items: { type: Type.STRING } },
            points: { type: Type.NUMBER }
        },
        required: ['text', 'type', 'correctAnswer', 'points']
    };
    
    let specificSchema;
    switch(type) {
        case QuestionType.MCQ:
            specificSchema = mcqSchema;
            break;
        case QuestionType.Essay:
            specificSchema = essaySchema;
            break;
        case QuestionType.FillInTheBlank:
            specificSchema = fillInTheBlankSchema;
            break;
        default:
            console.error("Unsupported question type for AI generation");
            return null;
    }

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-pro',
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.ARRAY,
                    items: specificSchema
                },
            }
        });

        const jsonText = response.text.trim();
        const generatedQuestions: Omit<Question, 'id'>[] = JSON.parse(jsonText);
        return generatedQuestions;

    } catch (error) {
        console.error("Error generating questions with AI:", error);
        return null;
    }
};