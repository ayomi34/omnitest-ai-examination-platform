import { User, Exam, Submission, Role, QuestionType } from '../types';

export const MOCK_USERS: User[] = [
  { id: 'u1', username: 'student1', fullName: 'Alex Johnson', role: Role.Student, email: 'alex@test.com', password: 'password123' },
  { id: 'u2', username: 'teacher1', fullName: 'Dr. Evelyn Reed', role: Role.Teacher, email: 'evelyn@test.com', password: 'password123' },
  { id: 'u3', username: 'admin1', fullName: 'Principal Skinner', role: Role.Admin, email: 'admin@test.com', password: 'password123' },
  { id: 'u4', username: 'student2', fullName: 'Ben Carter', role: Role.Student, email: 'ben@test.com', password: 'password123' },
];

export const MOCK_EXAMS: Exam[] = [
  {
    id: 'e1',
    title: 'Modern Physics Midterm',
    subject: 'Physics',
    duration: 60,
    teacherId: 'u2',
    questions: [
      {
        id: 'q1',
        text: 'What is the theory of relativity primarily concerned with?',
        type: QuestionType.MCQ,
        options: ['Quantum Mechanics', 'Spacetime', 'Thermodynamics', 'Optics'],
        correctAnswer: 'Spacetime',
        points: 1,
      },
      {
        id: 'q2',
        text: 'Explain the concept of wave-particle duality. Provide an example.',
        type: QuestionType.Essay,
        rubric: "5 pts - Clear definition of duality.\n5 pts - Accurate example (e.g., double-slit experiment).\n5 pts - Explanation of the example's significance.",
        points: 15,
      },
      {
        id: 'q3',
        text: 'The famous equation E=mc^2 was proposed by ___. The "c" in the equation represents the ___.',
        type: QuestionType.FillInTheBlank,
        correctAnswer: ['Einstein', 'speed of light'],
        points: 1,
      },
       {
        id: 'q4',
        text: 'Which of the following is NOT a fundamental force of nature?',
        type: QuestionType.MCQ,
        options: ['Gravity', 'Electromagnetism', 'Friction', 'Strong Nuclear Force'],
        correctAnswer: 'Friction',
        points: 1,
      },
    ],
  },
  {
    id: 'e2',
    title: 'World History Final',
    subject: 'History',
    duration: 90,
    teacherId: 'u2',
    questions: [
      {
        id: 'h1',
        text: 'The Renaissance began in which country?',
        type: QuestionType.MCQ,
        options: ['France', 'Spain', 'Italy', 'England'],
        correctAnswer: 'Italy',
        points: 1,
      },
      {
        id: 'h2',
        text: 'Analyze the primary causes of World War I.',
        type: QuestionType.Essay,
        rubric: "10 pts - Discussion of militarism, alliances, imperialism, and nationalism.\n5 pts - Mention of the assassination of Archduke Franz Ferdinand.\n5 pts - Clear structure and argument.",
        points: 20,
      },
    ],
  },
];

export const MOCK_SUBMISSIONS: Submission[] = [
    {
        id: 's1',
        examId: 'e1',
        studentId: 'u1',
        studentName: 'Alex Johnson',
        submittedAt: new Date('2023-10-26T10:00:00Z'),
        answers: {
            'q1': 'Spacetime',
            'q2': 'Wave-particle duality is the concept in quantum mechanics that every particle or quantum entity may be described as either a particle or a wave. An example is the double-slit experiment, where electrons behave like waves when not observed, but as particles when they are.',
            'q3': ['Einstein', 'speed of light'],
            'q4': 'Friction'
        },
        grades: {
            'q1': { score: 1, feedback: 'Correct' },
            'q3': { score: 1, feedback: 'Correct' },
            'q4': { score: 1, feedback: 'Correct' }
        },
        finalScore: 3,
    },
    {
        id: 's2',
        examId: 'e1',
        studentId: 'u4',
        studentName: 'Ben Carter',
        submittedAt: new Date('2023-10-26T10:05:00Z'),
        answers: {
            'q1': 'Quantum Mechanics',
            'q2': 'It means things can be waves and particles. Like light.',
            'q3': ['Newton', 'speed of sound'],
            'q4': 'Friction'
        },
        grades: {
            'q1': { score: 0, feedback: 'Incorrect' },
            'q3': { score: 0, feedback: 'Incorrect' },
            'q4': { score: 1, feedback: 'Correct' }
        },
        finalScore: 1,
    }
];